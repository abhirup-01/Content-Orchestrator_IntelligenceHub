import axios from "axios";

const getveevaData = () => { 
   
    // let sessionUrl = "  http://127.0.0.1:8000/list_approved_documents";

    let sessionUrl = "https://9kadvwq6mj.execute-api.us-east-1.amazonaws.com/list_approved_documents";
    const API_KEY = "5Nuq_sqnjk7s4b6_a7KKrZTb-IuFQBE2WXUupnHXn7g"
    // let sessionUrl = properties.GP_BASE_URL + 'Componentconfig/'+ upload_id;
    //console.log(sessionUrl);
    return axios.get(sessionUrl,{headers: {
            "X-API-KEY": API_KEY,
            "Content-Type": "application/json"
        }})
    // .then(response => {
    //   // Handle successful response
    //   console.log(response.data, response.status);
    // })
    .catch(function (error) {
      console.log("Error in getting veeva Data");
      console.log(error)
    });
  }

  export { getveevaData }

  /*return axios.get(sessionUrl,{headers: {
            "X-API-KEY": API_KEY,
            "Content-Type": "application/json"
        }}
    )*/
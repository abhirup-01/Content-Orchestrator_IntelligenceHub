// import React, { useMemo, useState, useEffect } from "react";
// import { useLocation, useNavigate } from "react-router-dom";
// import "../App.css";
// import { getProject, updateProjectMeta, markPhaseComplete, computeProgress } from '../lib/progressStore';
// import { usePhaseNavigation } from "./PhaseNav.jsx";
// import "./css/Regulatory.css";
// import {
//   ArrowLeft, Save, ArrowRight, Flag, Upload, FileText, CheckCircle2, Maximize2, BarChart3, FileDown,
//   Brain, Shield, Minimize2, Users, Stethoscope, Edit3, Plus, X, Pill, Unlock, CheckCircle, TrendingUp,
//   Languages, Loader2, Sparkles, Lock, Box, MessageSquare, Globe, CheckCircle as CheckCircleIcon
// } from 'lucide-react';

// /**
//  * Regulatory Compliance Hub (Destination page)
//  * - 3 Tabs: Compliance Review | Compliance Report | Regulatory Intelligence
//  * - Two cards: Left segments, Right detail (Source | Adapted | Compliant)
//  */
// export default function RegulatoryComplianceHub({
//   projectName: projectNameProp = "No project name to display",
//   therapyArea = "Respiratory · DE",
//   progressItems: progressItemsProp = { approved: 0, total: 15 },
//   segments: segmentsProp = [],
// }) {
//   const { state } = useLocation();
//   const navigate = useNavigate();

//   const projectId = state?.projectId;
//   const [projectRec, setProjectRec] = useState(null);
//   const totalTargetPhases = 4; // Define this clearly at the top

//   // 🆕 NEW: Add loading state. Starts true if we have a project.
//   const [isLoadingProject, setIsLoadingProject] = useState(!!projectId);
 
//   const refreshGlobalProgress = async () => {
//     if (projectId) {
//       const p = await getProject(projectId);
//       setProjectRec(p);
//       setIsLoadingProject(false);
//     }else {
//       setIsLoadingProject(false);
//     }
//   };
 
//   useEffect(() => {
//     refreshGlobalProgress();
//     window.addEventListener('glocal_progress_updated', refreshGlobalProgress);
//     return () => window.removeEventListener('glocal_progress_updated', refreshGlobalProgress);
//   }, [projectId]);
 
//   // Wrap in useMemo for performance and safety
//   // const progressData = useMemo(() => {
//   //   // If project hasn't loaded, default to 75% (since we are in Phase 4)
//   //   if (!projectRec) {
//   //     return { count: 3, percent: 75, set: new Set(['P1', 'P2', 'P3']) };
//   //   }
 
//   //   const { completedSet } = computeProgress(projectRec);
//   //   const count = Math.min(completedSet.size, totalTargetPhases);
//   //   const percent = Math.round((count / totalTargetPhases) * 100);
 
//   //   return { count, percent, set: completedSet };
//   // }, [projectRec]);
//   // Wrap in useMemo for performance and safety
//   // const progressData = useMemo(() => {
//   //   // 🆕 1. Check local storage synchronously to stop the progress bar jumping
//   //   let recToUse = projectRec;
//   //   if (!recToUse && projectId) {
//   //     const db = JSON.parse(localStorage.getItem('glocal_progress_v1') || '{}');
//   //     recToUse = db[projectId];
//   //   }

//   //   // 2. Safe fallback if completely empty
//   //   if (!recToUse) {
//   //     return { count: 3, percent: 'Loading...' , set: new Set(['P1', 'P2', 'P3']) };
//   //   }
 
//   //   const { completedSet } = computeProgress(recToUse);
//   //   const count = Math.min(completedSet.size, totalTargetPhases);
//   //   const percent = Math.round((count / totalTargetPhases) * 100);
 
//   //   return { count, percent, set: completedSet };
//   // }, [projectRec, projectId]);
 
//   // // Unified variable names to match all your JSX parts
//   // const completedCount = progressData.count;
//   // const overallPercent = progressData.percent;
//   // const completedSet   = progressData.set;
 
//   // // Aliases to prevent "ReferenceError" in different parts of your file
//   // const overallPct  = overallPercent;
//   // const progressPct = overallPercent;

//   // ✅ 1. UPDATED: Provide the isProgressLoading state
//   //Hari-24/3
//   // const progressData = useMemo(() => {
//   //   if (!projectRec) {
//   //     // Return a temporary loading state while the database is fetching
//   //     return { count: 0, percent: 0, set: new Set(), isProgressLoading: true };
//   //   }
 
//   //   const { completedSet } = computeProgress(projectRec);
//   //   const count = Math.min(completedSet.size, totalTargetPhases);
//   //   const percent = Math.round((count / totalTargetPhases) * 100);
 
//   //   return { count, percent, set: completedSet, isProgressLoading: false };
//   // }, [projectRec]);
 
//   // // Unified variable names to match all your JSX parts
//   // const completedCount = progressData.count;
//   // const overallPercent = progressData.percent;
//   // const completedSet   = progressData.set;
//   // const isProgressLoading = progressData.isProgressLoading; // 🆕 Extracted safely!
 
//   // // Aliases to prevent "ReferenceError" in different parts of your file
//   // const overallPct  = overallPercent;
//   // const progressPct = overallPercent;

//   //Kathir-25/3-------------------------------------
//   // const progressData = useMemo(() => {
//   //   let recToUse = projectRec;
 
//   //   // Synchronous fallback: If React state (projectRec) hasn't loaded yet,
//   //   // immediately check localStorage to prevent the progress bar from flickering.
//   //   if (!recToUse && projectId) {
//   //     try {
//   //       const rawDb = localStorage.getItem('glocal_progress_v1');
//   //       const db = JSON.parse(rawDb || '{}');
//   //       recToUse = db[projectId];
//   //     } catch (e) {
//   //       console.error("Error reading progress from localStorage:", e);
//   //     }
//   //   }
 
//   //   // If still no record exists, return the temporary loading state
//   //   if (!recToUse) {
//   //     return { count: 0, percent: 0, set: new Set(), isProgressLoading: true };
//   //   }
 
//   //   // Calculate progress based on the guaranteed latest data
//   //   const { completedSet } = computeProgress(recToUse);
//   //   const count = Math.min(completedSet.size, totalTargetPhases);
//   //   const percent = Math.round((count / totalTargetPhases) * 100);
 
//   //   return { count, percent, set: completedSet, isProgressLoading: !projectRec };
//   // }, [projectRec, projectId]); // Added projectId to dependencies
 
//   // // Unified variable names to match all your JSX parts
//   // const completedCount = progressData.count;
//   // const overallPercent = progressData.percent;
//   // const completedSet   = progressData.set;
//   // const isProgressLoading = progressData.isProgressLoading;
 
//   // // Aliases to prevent "ReferenceError" in different parts of your file
//   // const overallPct  = overallPercent;
//   // const progressPct = overallPercent;

//   // ✅ UPGRADED UNIVERSAL CACHE
//   const progressData = useMemo(() => {
//     let recToUse = projectRec;
//     const isRecEmpty = !recToUse || Object.keys(recToUse).length === 0;

//     // Synchronous fallback: If React state hasn't loaded or is empty, grab from cache
//     if (isRecEmpty && projectId) {
//       try {
//         const rawDb = localStorage.getItem('glocal_progress_v1');
//         const db = JSON.parse(rawDb || '{}');
//         if (db[projectId]) {
//             recToUse = db[projectId];
//         }
//       } catch (e) {
//         console.error("Error reading progress from localStorage:", e);
//       }
//     }

//     // If still no record exists anywhere
//     if (!recToUse || Object.keys(recToUse).length === 0) {
//       return { 
//         count: 0, 
//         percent: 0, 
//         set: new Set(), 
//         isProgressLoading: isRecEmpty 
//       };
//     }

//     // Calculate progress based on the guaranteed latest data
//     const { completedSet } = computeProgress(recToUse);
//     const count = Math.min(completedSet.size, totalTargetPhases);

//     return {
//       count: count,
//       percent: Math.round((count / totalTargetPhases) * 100),
//       set: completedSet,
//       isProgressLoading: !projectRec || Object.keys(projectRec).length === 0
//     };
//   }, [projectRec, projectId]);

//   // Unified variable names to match all your JSX parts
//   const completedCount = progressData.count;
//   const overallPercent = progressData.percent;
//   const completedSet   = progressData.set;
//   const isProgressLoading = progressData.isProgressLoading;
 
//   // Aliases to prevent "ReferenceError" in different parts of your file
//   const overallPct  = overallPercent;
//   const progressPct = overallPercent;
//   const country = state?.country ?? null;
//   console.log(country);
//   const projectName = state?.projectName ?? projectNameProp;
//   const gotoPhase = usePhaseNavigation(projectId, projectName,country); //31_03_sanju

//   // const projectRec = useMemo(() => getProject(projectId), [projectId]);

//   // const persistedSegmentsP4 = useMemo(
//   //   () =>
//   //     (projectRec?.meta?.segmentsP4 && Array.isArray(projectRec.meta.segmentsP4))
//   //       ? projectRec.meta.segmentsP4
//   //       : [],
//   //   [projectRec]
//   // );

//   // const persistedSegmentsP3 = useMemo(
//   //   () => (projectRec?.meta?.segmentsP3 && Array.isArray(projectRec.meta.segmentsP3))
//   //     ? projectRec.meta.segmentsP3 : [],
//   //   [projectRec]
//   // );
//   // const persistedSegmentsP2 = useMemo(
//   //   () => (projectRec?.meta?.segmentsP2 && Array.isArray(projectRec.meta.segmentsP2))
//   //     ? projectRec.meta.segmentsP2 : [],
//   //   [projectRec]
//   // );


 

 
//   // ✅ Wrapped in useMemo to stop the infinite loop!
//   const persistedSegmentsP4 = useMemo(() => projectRec?.meta?.segmentsP4 || [], [projectRec]);
//   const persistedSegmentsP3 = useMemo(() => projectRec?.meta?.segmentsP3 || [], [projectRec]);
//   const persistedSegmentsP2 = useMemo(() => projectRec?.meta?.segmentsP2 || [], [projectRec]);

//   // --- Focus mode state (unique key for Cultural page) ---
//   const [isFocusMode, setIsFocusMode] = useState(() => {
//     const v = localStorage.getItem('ci_focus_mode');
//     return v === 'true';
//   });

//   const toggleFocusMode = () => setIsFocusMode(prev => !prev);

//   // persist on change
//   useEffect(() => {
//     localStorage.setItem('ci_focus_mode', String(isFocusMode));
//   }, [isFocusMode]);

//   // keyboard: F to focus, Esc to exit
//   useEffect(() => {
//     const onKey = (e) => {
//       const k = String(e.key || '').toLowerCase();
//       if (k === 'f') setIsFocusMode(true);
//       if (k === 'escape') setIsFocusMode(false);
//     };
//     window.addEventListener('keydown', onKey);
//     return () => window.removeEventListener('keydown', onKey);
//   }, []);

//   // ===== n8n Endpoint (configure via env) =====
//   const N8N_COMPLIANCE_URL =
//     (typeof import.meta !== "undefined" &&
//       import.meta.env &&
//       import.meta.env.VITE_N8N_COMPLIANCE_URL) ||
//     process.env.REACT_APP_N8N_COMPLIANCE_URL ||
//     "http://172.16.4.237:8016/webhook/regulatory";

//   /* ================= LANGUAGE HELPERS ================= */
//   const getTargetLang = (therapyAreaStr) => {
//     const m = String(therapyAreaStr || "").match(/·\s*([A-Za-z-]+)/);
//     return m?.[1] || "DE";
//   };

//   /** Normalize incoming segments from router state */
//   const segments = useMemo(() => {
//     const rawCandidate =
//       (Array.isArray(state?.segments) && state.segments.length > 0)
//         ? state.segments
//         : (Array.isArray(persistedSegmentsP4) && persistedSegmentsP4.length > 0)
//           ? persistedSegmentsP4
//           : (Array.isArray(persistedSegmentsP3) && persistedSegmentsP3.length > 0)
//             ? persistedSegmentsP3
//             : (Array.isArray(persistedSegmentsP2) && persistedSegmentsP2.length > 0)
//               ? persistedSegmentsP2
//               : (Array.isArray(segmentsProp) && segmentsProp.length > 0)
//                 ? segmentsProp
//                 : [];

//     return (rawCandidate || [])
//       .map((seg, i) => {
//         const index = typeof seg.index === "number" ? seg.index : i + 1;
//         const source = String(seg.source ?? "");
//         const adapted = String(seg.adapted ?? seg.culturallyAdapted ?? seg.translated ?? ""); // phase 3 result if present
//         const compliant = String(seg.compliant ?? ""); // phase 4 will fill this
//         const words =
//           typeof seg.words === "number"
//             ? seg.words
//             : source.split(/\s+/).filter(Boolean).length;

//         return {
//           id: seg.id ?? `seg-${index}`,
//           index,
//           source,
//           adapted,   // shown under "Culturally Adapted Text (Phase 3)"
//           compliant, // shown under "Regulatory Compliant Text"
//           words,
//           status: seg.status ?? (adapted.trim() ? "Pending" : "Pending"),
//           lang: seg.lang ?? "EN",
//           complianceScore: typeof seg.complianceScore === "number" ? seg.complianceScore : null,
//         };
//       })
//       .filter((s) => s.source.trim().length > 0)
//       .sort((a, b) => a.index - b.index);
//   }, [state?.segments, segmentsProp, persistedSegmentsP4, persistedSegmentsP3, persistedSegmentsP2]);

//   /** Selected segment */
//   const [selectedId, setSelectedId] = useState(null);
//   useEffect(() => {
//     if (!selectedId && segments.length) setSelectedId(segments[0].id);
//   }, [segments, selectedId]);
//   const selected = useMemo(
//     () => segments.find((s) => s.id === selectedId) || null,
//     [segments, selectedId]
//   );

//   /** Local UI state for score & compliant text (per selection) */
//   const [scoreById, setScoreById] = useState({});
//   const [compliantById, setCompliantById] = useState({});
//   const [hasHydrated, setHasHydrated] = useState(false);

//   useEffect(() => {
//     // 🆕 If we have already loaded the data, DO NOT run this again! (Stops the freeze)
//     //if (!segments || segments.length === 0 || hasHydrated) return;

//     if (isLoadingProject || hasHydrated || !segments || segments.length === 0) return;

//     const initialScores = {};
//     const initialCompliant = {};
//     const initialOverrides = {};

//     segments.forEach((s) => {
//       if (typeof s.complianceScore === "number") initialScores[s.id] = s.complianceScore;
//       if (s.compliant?.trim()) initialCompliant[s.id] = s.compliant;
//       if (s.status || s.compliantText || s.mlr || s.mlrDefer || s.acceptedRisk || s.blocked) {
//         initialOverrides[s.id] = {
//           ...(s.status ? { status: s.status } : {}),
//           ...(s.compliantText ? { compliantText: s.compliantText } : {}),
//           ...(s.mlr ? { mlr: s.mlr } : {}),
//           ...(s.mlrDefer ? { mlrDefer: s.mlrDefer } : {}),
//           ...(s.acceptedRisk ? { acceptedRisk: s.acceptedRisk } : {}),
//           ...(s.blocked ? { blocked: s.blocked } : {}),
//         };
//       }
//     });
    
//     // 🆕 Set the state directly
//     setScoreById(initialScores);
//     setCompliantById(initialCompliant);
//     setSegOverrides(initialOverrides);
    
//     // 🆕 ENGAGE THE LOCK
//     setHasHydrated(true); 
    
//   }, [segments, hasHydrated, isLoadingProject]);

//   /** Progress (approved count) */
//   const progressItems = useMemo(() => {
//     const total = segments.length || progressItemsProp.total || 0;
//     const approved = segments.filter((s) => (compliantById[s.id] || s.compliant || "").trim().length > 0).length;
//     return total > 0 ? { approved, total } : progressItemsProp;
//   }, [segments, compliantById, progressItemsProp]);
//   /* ================= PER-SEGMENT OVERRIDES ================= */
//   const [segOverrides, setSegOverrides] = useState({});
  
  
//   const selectedResolved = useMemo(() => {
//     if (!selected) return null;
//     return { ...selected, ...(segOverrides[selected.id] || {}) };
//   }, [selected, segOverrides]);

//   const currentSegOverride = segOverrides[selectedResolved?.id] || {};

//   const buildP4Segments = () =>
//     segments.map((s) => {
//       const o = segOverrides[s.id] || {};
//       return {
//         ...s,
//         complianceScore: scoreById[s.id] ?? s.complianceScore ?? null,
//         compliant: compliantById[s.id] ?? s.compliant ?? "",
//         status: o.status ?? s.status ?? "Pending",
//         ...(o.compliantText ? { compliantText: o.compliantText } : {}),
//         ...(o.mlr ? { mlr: o.mlr } : {}),
//         ...(o.mlrDefer ? { mlrDefer: o.mlrDefer } : {}),
//         ...(o.acceptedRisk ? { acceptedRisk: o.acceptedRisk } : {}),
//         ...(o.blocked ? { blocked: o.blocked } : {}),
//       };
//     });

//   // ✅ REAL AUTO-SAVE DEBOUNCE
//   useEffect(() => {
//     // 🆕 Don't start saving until the page has safely loaded
//     if (!projectId || !hasHydrated) return; 

//     // 🆕 Wait 1.5 seconds after the user STOPS clicking/typing before saving
//     const timeoutId = setTimeout(() => {
//       try {
//         updateProjectMeta(projectId, { segmentsP4: buildP4Segments() });
//       } catch { }
//     }, 1500); 

//     return () => clearTimeout(timeoutId);
//   }, [projectId, segOverrides, scoreById, compliantById, segments, hasHydrated]);

//   /* ================= PROGRESS ================= */
//   const approvedCount = useMemo(() => {
//     return segments.filter((s) => {
//       const o = segOverrides[s.id] || {};
//       const status = String(o.status ?? s.status ?? "Pending").toLowerCase();
//       return status === "approved";
//     }).length;
//   }, [segments, segOverrides]);

//   const flaggedCount = useMemo(() => {
//     return segments.filter((s) => {
//       const o = segOverrides[s.id] || {};
//       const status = String(o.status ?? s.status ?? "Pending").toLowerCase();
//       return status === "flagged";
//     }).length;
//   }, [segments, segOverrides]);

//   const changedCount = useMemo(() => {
//     return segments.filter((s) => {
//       const o = segOverrides[s.id] || {};
//       return Boolean((o.compliantText || "").trim());
//     }).length;
//   }, [segments, segOverrides]);

//   const totalCount = segments.length;
  
//   // 🆕 NEW: Calculate the local percentage just for Phase 4 segments
//   const localProgressPct = totalCount > 0 
//     ? Math.round((approvedCount / totalCount) * 100) 
//     : 0;
  

//   /** Sidebar: retain context when moving across phases 31_03_sanju */
//   const handlePhaseClick = (phaseName) => {
//     if (phaseName === "Global Context Capture") {
//       navigate("/globalAssetCapture", { state: {projectId, projectName, segments,country } });
//     }
//     if (phaseName === "Smart TM Translation") {
//       navigate("/smartTMTranslationHub", { state: { projectId, projectName, segments, country } });
//     }
//     if (phaseName === "Cultural Intelligence") {
//       navigate("/culturalAdaptationWorkspace", { state: { projectId, projectName, segments, country } });
//     }
//   };

//   /* ================= MAIN TABS (Top) ================= */
//   const [mainTab, setMainTab] = useState("review"); // review | report | intel

//   /* ================= ANALYSIS MODAL (n8n renders-only under Critical Issues & Recommendations) ================= */
//   const [isAnalysisModalOpen, setIsAnalysisModalOpen] = useState(false);
//   const [activeTab, setActiveTab] = useState("issues"); // issues | pre | templates
//   const [isReAnalyzing, setIsReAnalyzing] = useState(false);
//   const [isAnalyzing, setIsAnalyzing] = useState(false);

//   const [analysisData, setAnalysisData] = useState({
//     score: 70,
//     risk: "MEDIUM",
//     criticalIssues: [], // keep empty (we only show n8n)
//     recommendations: [], // keep empty (we only show n8n)
//   });

//   // n8n results rendered under Critical Issues & Recommendations
//   const [n8nCritical, setN8nCritical] = useState([]); // [{id, text}]
//   const [n8nRecs, setN8nRecs] = useState([]); // [{id, text}]
//   const [n8nLoading, setN8nLoading] = useState(false);
//   const [n8nError, setN8nError] = useState("");

//   // Utility: normalize an array of strings into [{id, text}]
//   const normalizeStringArray = (arr = [], prefix = "item") =>
//     Array.isArray(arr)
//       ? arr.map((t, i) => ({ id: `${prefix}-${i + 1}`, text: String(t) }))
//       : [];

//   // Minimal HTML entity decoding for webhook payloads
//   const decodeHtmlEntities = (s = "") =>
//     String(s || "")
//       .replace(/&amp;/g, "&")
//       .replace(/&lt;/g, "<")
//       .replace(/&gt;/g, ">")
//       .replace(/&quot;/g, '"')
//       .replace(/&#39;/g, "'");

//   // Split enumerated text like: "1. Item one. 2. Item two. 3. Item three."
//   const splitEnumeratedText = (text) => {
//     const t = decodeHtmlEntities(String(text || "")).trim();
//     if (!t) return [];

//     // Insert a delimiter before each "N. " sequence (start or after whitespace/punct)
//     const withDelims = t.replace(/(^|[\s;])(\d+)\.\s+/g, "||SEP||");
//     const parts = withDelims
//       .split("||SEP||")
//       .map((p) => p.trim().replace(/^[.;-]+\s*/, ""))
//       .filter(Boolean);

//     if (parts.length <= 1) {
//       const fallback = t
//         .split(/\n+|•\s+/g)
//         .map((p) => p.trim())
//         .filter(Boolean);
//       return fallback.length > 1 ? fallback : parts;
//     }

//     return parts;
//   };

//   /* ===================== NEW: score & risk helpers ===================== */
//   const normalizeScore = (v) => {
//     if (v == null) return null;
//     if (typeof v === "number" && Number.isFinite(v)) {
//       return Math.max(0, Math.min(100, Math.round(v)));
//     }
//     if (typeof v === "string") {
//       // Accept "82", "82%", "82/100", "Score: 82"
//       const mPct = v.match(/(\d{1,3})\s*%/);
//       const mSlash = v.match(/(\d{1,3})\s*\/\s*100/);
//       const mNum = v.match(/(\d{1,3})/);
//       let n = null;
//       if (mPct) n = parseInt(mPct[1], 10);
//       else if (mSlash) n = parseInt(mSlash[1], 10);
//       else if (mNum) n = parseInt(mNum[1], 10);
//       if (Number.isFinite(n)) {
//         return Math.max(0, Math.min(100, n));
//       }
//     }
//     return null;
//   };

//   const computeRiskFromScore = (score) => {
//     if (!Number.isFinite(score)) return "MEDIUM";
//     if (score >= 75) return "LOW";
//     if (score >= 50) return "MEDIUM";
//     return "HIGH";
//   };

//   // ===== Parser for the provided n8n output shape (+ score & risk support) =====
//   // Expected: [ { output: { critical_issue, recommendation1, recommendation2, (optional) score/compliance_score, (optional) risk } } ]
//   const parseN8nShape_CritAndRecs = (payload) => {
//     try {
//       let score = null;
//       let risk = null;

//       if (!Array.isArray(payload)) return { crit: [], recs: [], score, risk };

//       const first = payload[0];
//       const out = first?.output ?? first?.Output ?? null;

//       if (out && typeof out === "object") {
//         const critical_issue = decodeHtmlEntities(String(out.critical_issue || "").trim());
//         const recommendation1 = decodeHtmlEntities(String(out.recommendation1 || "").trim());
//         const recommendation2 = decodeHtmlEntities(String(out.recommendation2 || "").trim());

//         // NEW: optional score / risk fields
//         const rawScore = out.score ?? out.compliance_score ?? out.overall_score ?? null;
//         score = normalizeScore(rawScore);

//         const rawRisk = (out.risk ?? out.risk_level ?? "").toString().trim();
//         if (rawRisk) {
//           risk = rawRisk.toUpperCase();
//         }

//         const crit = critical_issue
//           ? [{ id: "n8n-crit-1", text: critical_issue }]
//           : [];

//         const recs = []
//           .concat(recommendation1 ? [{ id: "n8n-rec-1", text: recommendation1 }] : [])
//           .concat(recommendation2 ? [{ id: "n8n-rec-2", text: recommendation2 }] : []);

//         return { crit, recs, score, risk };
//       }

//       // Fallback: if shape is different, try to split strings
//       if (typeof first?.output === "string") {
//         const parts = splitEnumeratedText(first.output);
//         const crit = parts[0] ? [{ id: "n8n-crit-1", text: parts[0] }] : [];
//         const recs = []
//           .concat(parts[1] ? [{ id: "n8n-rec-1", text: parts[1] }] : [])
//           .concat(parts[2] ? [{ id: "n8n-rec-2", text: parts[2] }] : []);
//         // No score/risk in this shape
//         return { crit, recs, score: null, risk: null };
//       }

//       return { crit: [], recs: [], score: null, risk: null };
//     } catch {
//       return { crit: [], recs: [], score: null, risk: null };
//     }
//   };

//   // (Legacy parser retained for safety if workflows change to earlier string shapes)
//   const extractN8nCriticalFromCustomShape = (payload) => {
//     try {
//       if (Array.isArray(payload) && typeof payload[0]?.output === "string") {
//         const out = payload[0].output;

//         // Try JSON-in-a-string first (in case)
//         try {
//           const parsed = JSON.parse(out);
//           if (Array.isArray(parsed) && parsed.every((x) => typeof x === "string")) {
//             return normalizeStringArray(parsed, "n8n-crit");
//           }
//           if (
//             parsed &&
//             typeof parsed === "object" &&
//             Array.isArray(parsed.US_Pharma_Regulatory_Rules)
//           ) {
//             return normalizeStringArray(parsed.US_Pharma_Regulatory_Rules, "n8n-crit");
//           }
//         } catch {
//           // Not JSON; fall through to enumerated split
//         }

//         const items = splitEnumeratedText(out);
//         return normalizeStringArray(items, "n8n-crit");
//       }

//       // Fallbacks
//       if (payload && typeof payload === "object") {
//         const maybeArr =
//           payload.criticalIssues ||
//           payload.issues ||
//           (Array.isArray(payload) ? payload : []);
//         if (Array.isArray(maybeArr) && maybeArr.every((x) => typeof x === "string")) {
//           return normalizeStringArray(maybeArr, "n8n-crit");
//         }
//       }

//       if (Array.isArray(payload) && payload.every((x) => typeof x === "string")) {
//         return normalizeStringArray(payload, "n8n-crit");
//       }

//       return [];
//     } catch {
//       return [];
//     }
//   };

//   const openAnalysisModal = async () => {
//     if (!selectedResolved?.adapted?.trim()) return;

//     // Ensure local lists are EMPTY (we only show n8n content)
//    setAnalysisData({
//   score: null, // Makes the score empty
//   risk: "",   // Makes the risk empty
//   criticalIssues: [],
//   recommendations: [],
// });

//     // Open modal immediately
//     setActiveTab("issues");
//     setIsAnalysisModalOpen(true);

//     // Begin async n8n call – results will render under Critical Issues and Recommended Changes
//     setN8nCritical([]);
//     setN8nRecs([]);
//     setN8nError("");
//     setN8nLoading(true);
//     setIsAnalyzing(true);

//     const payload = {
//       projectName,
//       therapyArea,
//       segmentId: selectedResolved.id,
//       index: selectedResolved.index,
//       adaptedText: selectedResolved.adapted,
//       country
//     };
//     console.log('Posting to n8n:', {
//       projectName,
//       therapyArea,
//       segmentId: selectedResolved?.id,
//       index: selectedResolved?.index,
//       adaptedText: selectedResolved?.adapted,
//       country,
//     });

//     try {
//       const res = await fetch(N8N_COMPLIANCE_URL, {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify(payload),
//       });

//       if (!res.ok) {
//         const txt = await res.text().catch(() => "");
//         throw new Error(
//           `n8n responded with ${res.status}${txt ? ` - ${txt.slice(0, 180)}` : ""}`
//         );
//       }

//       const raw = await res.json().catch(() => null);

//       // Prefer the specific shape (critical_issue, recommendation1, recommendation2, score?, risk?)
//       const { crit, recs, score, risk } = parseN8nShape_CritAndRecs(raw);

//       // ===== NEW: apply score & risk from n8n if present =====
//       if (Number.isFinite(score)) {
//         // Update modal "Overall Compliance Score"
//         setAnalysisData((prev) => ({
//           ...prev,
//           score,
//           risk: risk || computeRiskFromScore(score),
//         }));

//         // Also persist per-segment score (updates the badge in the Adapted card)
//         setScoreById((prev) => ({ ...prev, [selectedResolved.id]: score }));
//       } else {
//         // If no score provided but risk provided, still update risk
//         if (risk) {
//           setAnalysisData((prev) => ({ ...prev, risk }));
//         }
//       }

//       // Critical
//       if ((crit || []).length === 0) {
//         // Fallback to legacy extraction if no crit found
//         const legacyCrit = extractN8nCriticalFromCustomShape(raw);
//         if (legacyCrit.length > 0) {
//           setN8nCritical(legacyCrit);
//         } else {
//           setN8nError("No critical issue returned by AI for this segment.");
//         }
//       } else {
//         setN8nCritical(crit);
//       }

//       // Recommendations (ONLY from n8n)
//       setN8nRecs(recs || []);
//     } catch (err) {
//       setN8nError(err?.message || "Failed to analyze with AI.");
//     } finally {
//       setN8nLoading(false);
//       setIsAnalyzing(false);
//     }
//   };

//   const [isReAnalyzeDisabled] = useState(false);

//   const compliantEditorValue = selectedResolved?.compliantText ?? "";
//   const setCompliantEditorValue = (val) => {
//     if (!selectedResolved) return;
//     setSegOverrides((prev) => ({
//       ...prev,
//       [selectedResolved.id]: {
//         ...prev[selectedResolved.id],
//         compliantText: val,
//       },
//     }));
//   };

//   const handleApprove = () => {
//     if (!selectedResolved) return;
//     setSegOverrides((prev) => ({
//       ...prev,
//       [selectedResolved.id]: {
//         ...prev[selectedResolved.id],
//         status: "Approved",
//       },
//     }));
//   };

//   const handleFlag = () => {
//     if (!selectedResolved) return;
//     setSegOverrides((prev) => ({
//       ...prev,
//       [selectedResolved.id]: {
//         ...prev[selectedResolved.id],
//         status: "Flagged",
//       },
//     }));
//   };

//   /* ============ Analysis actions ============ */
//   const applyCompliantSuggestion = (recText) => {
//     const appended =
//       (selectedResolved?.compliantText || "").trim().length > 0
//         ? selectedResolved.compliantText + "\n\n" + "• " + recText
//         : "• " + recText;
//     setCompliantEditorValue(appended);
//   };

//   const acceptRecommendation = (recText) => {
//     const appended =
//       (selectedResolved?.compliantText || "").trim().length > 0
//         ? selectedResolved.compliantText + "\n\n" + "• " + recText
//         : "• " + recText;
//     setCompliantEditorValue(appended);
//   };

//   const reAnalyzeInModal = async () => {
//     setIsReAnalyzing(true);
//     setTimeout(() => setIsReAnalyzing(false), 800);
//   };

//   const markCompliantFromModal = () => {
//     handleApprove();
//     setIsAnalysisModalOpen(false);
//   };

//   //Hari
//   // const handleCompleteCompliance = async () => {
//   //   if (!projectId) return;
//   //   try {
//   //     // 1. Mark Phase 4 (Regulatory) as complete in the DB
//   //     //Hari
//   //     await markPhaseComplete(projectId, 'P4');
     
//   //     // 2. Trigger the local event to refresh the progress bar immediately
//   //     window.dispatchEvent(new Event('glocal_progress_updated'));
     
//   //     console.log("Compliance phase marked as complete.");
//   //   } catch (err) {
//   //     console.error("Failed to complete phase:", err);
//   //   }
//   // };

//   //Kathir-25/3
//     const handleCompleteCompliance = async () => {
//     if (!projectId) return;
//     try {
//       // 1. Mark Phase 4 (Regulatory) as complete in the DB
//       await markPhaseComplete(projectId, 'P4');
     
//       // ✅ FIX: Micro-delay to ensure the Sidebar and Progress Ring
//       // receive the "100%" update event before the function finishes.
//       await new Promise(resolve => setTimeout(resolve, 50));
     
//       // 2. Trigger the local event to refresh the progress bar immediately
//       window.dispatchEvent(new Event('glocal_progress_updated'));
     
//       console.log("Compliance phase marked as complete. Progress should now be 100%.");
//     } catch (err) {
//       console.error("Failed to complete phase:", err);
//     }
//   };
 

//   /* ================= Request MLR Exception ================= */
//   const [isMlrOpen, setIsMlrOpen] = useState(false);
//   const [mlrRuleText, setMlrRuleText] = useState("");
//   const [mlrReason, setMlrReason] = useState("");
//   const [mlrTouched, setMlrTouched] = useState(false);
//   const [mlrSubmitting, setMlrSubmitting] = useState(false);

//   const openMlrModal = (ruleText) => {
//     setMlrRuleText(ruleText || "");
//     setMlrReason("");
//     setMlrTouched(false);
//     setIsMlrOpen(true);
//   };

//   const submitMlr = async () => {
//     setMlrTouched(true);
//     if (!mlrReason.trim()) return;
//     setMlrSubmitting(true);

//     const payload = {
//       rule: mlrRuleText,
//       reasoning: mlrReason.trim(),
//       at: new Date().toISOString(),
//     };

//     setSegOverrides((prev) => ({
//       ...prev,
//       [selectedResolved.id]: {
//         ...prev[selectedResolved.id],
//         status: "Flagged",
//         mlr: payload,
//       },
//     }));

//     setTimeout(() => {
//       setMlrSubmitting(false);
//       setIsMlrOpen(false);
//     }, 300);
//   };

//   /* ================= Defer to MLR Review ================= */
//   const [isDeferOpen, setIsDeferOpen] = useState(false);
//   const [deferRuleText, setDeferRuleText] = useState("");
//   const [deferReason, setDeferReason] = useState("");
//   const [deferTouched, setDeferTouched] = useState(false);
//   const [deferSubmitting, setDeferSubmitting] = useState(false);

//   const openDeferModal = (ruleText) => {
//     setDeferRuleText(ruleText || "");
//     setDeferReason("");
//     setDeferTouched(false);
//     setIsDeferOpen(true);
//   };

//   const submitDefer = async () => {
//     setDeferTouched(true);
//     if (!deferReason.trim()) return;
//     setDeferSubmitting(true);

//     const payload = {
//       rule: deferRuleText,
//       reasoning: deferReason.trim(),
//       at: new Date().toISOString(),
//     };

//     setSegOverrides((prev) => ({
//       ...prev,
//       [selectedResolved.id]: {
//         ...prev[selectedResolved.id],
//         status: "Flagged",
//         mlrDefer: payload,
//       },
//     }));

//     setTimeout(() => {
//       setDeferSubmitting(false);
//       setIsDeferOpen(false);
//     }, 300);
//   };

//   /* ================= Accept Risk & Skip ================= */
//   const [isRiskOpen, setIsRiskOpen] = useState(false);
//   const [riskRuleText, setRiskRuleText] = useState("");
//   const [riskReason, setRiskReason] = useState("");
//   const [riskTouched, setRiskTouched] = useState(false);
//   const [riskSubmitting, setRiskSubmitting] = useState(false);

//   const openRiskModal = (ruleText) => {
//     setRiskRuleText(ruleText || "");
//     setRiskReason("");
//     setRiskTouched(false);
//     setIsRiskOpen(true);
//   };

//   const submitRisk = async () => {
//     setRiskTouched(true);
//     if (!riskReason.trim()) return;
//     setRiskSubmitting(true);

//     const payload = {
//       rule: riskRuleText,
//       reasoning: riskReason.trim(),
//       at: new Date().toISOString(),
//     };

//     setSegOverrides((prev) => ({
//       ...prev,
//       [selectedResolved.id]: {
//         ...prev[selectedResolved.id],
//         acceptedRisk: payload,
//       },
//     }));

//     setTimeout(() => {
//       setRiskSubmitting(false);
//       setIsRiskOpen(false);
//     }, 300);
//   };

//   /* ================= Mark as Blocking ================= */
//   const [isBlockOpen, setIsBlockOpen] = useState(false);
//   const [blockRuleText, setBlockRuleText] = useState("");
//   const [blockReason, setBlockReason] = useState(
//     "Marked as blocking - must be resolved before approval"
//   );
//   const [blockTouched, setBlockTouched] = useState(false);
//   const [blockSubmitting, setBlockSubmitting] = useState(false);

//   const openBlockModal = (ruleText) => {
//     setBlockRuleText(ruleText || "");
//     setBlockReason("Marked as blocking - must be resolved before approval");
//     setBlockTouched(false);
//     setIsBlockOpen(true);
//   };

//   const submitBlock = async () => {
//     setBlockTouched(true);
//     if (!blockReason.trim()) return;
//     setBlockSubmitting(true);

//     const payload = {
//       rule: blockRuleText,
//       reasoning: blockReason.trim(),
//       at: new Date().toISOString(),
//     };

//     setSegOverrides((prev) => ({
//       ...prev,
//       [selectedResolved.id]: {
//         ...prev[selectedResolved.id],
//         status: "Flagged",
//         blocked: payload,
//       },
//     }));

//     setTimeout(() => {
//       setBlockSubmitting(false);
//       setIsBlockOpen(false);
//       setIsAnalysisModalOpen(false);
//     }, 300);
//   };

//   /* ================= Navigation ================= */
//   const goBack = () => navigate(-1);

//   /* ================= Derived: Report / Intel ================= */
//   const avgCompliance = totalCount ? Math.round((approvedCount / totalCount) * 100) : 0;
//   const criticalIssuesCount = 0; // left as-is (report widgets unchanged)
//   const totalChanges = changedCount;
// const overallComplianceScoreFromModal = analysisData?.score ?? null; // number | null

//   /* ================= Export Report (simple .txt) ================= */
//   const exportReport = () => {
//     const lines = [
//       `Project: ${projectName}`,
//       `Therapy Area: ${therapyArea}`,
//       `Generated: ${new Date().toLocaleString()}`,
//       "",
//       "Final Regulatory-Compliant Translation",
//       "======================================",
//       "",
//       ...segments.map((seg) => {
//         const adapted = (seg.adapted || "").trim() ? seg.adapted : "— No adapted text —";
//         return `Segment ${seg.index}\n${adapted}\n`;
//       }),
//     ];
//     const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
//     const url = URL.createObjectURL(blob);
//     const a = document.createElement("a");
//     a.href = url;
//     a.download = `${projectName.replace(/\s+/g, "_")}_Compliance_Report.txt`;
//     a.click();
//     URL.revokeObjectURL(url);
//   };

//   /** Heuristic score (still available for manual Run Compliance Check button) */
//   const heuristicScore = (text) => {
//     const t = String(text || "");
//     const base = Math.min(100, Math.round(t.length / 3));
//     const hasBrand = /ofev|nintedanib/i.test(t);
//     const hasRisk = /risk|warning|contraindication/i.test(t);
//     return Math.max(0, Math.min(100, base + (hasBrand ? 10 : 0) + (hasRisk ? 8 : 0)));
//   };

//   /** Actions on detail panel */
//   const runComplianceCheck = () => {
//     if (!selected) return;
//     const score = heuristicScore(selected.adapted);
//     setScoreById((prev) => ({ ...prev, [selected.id]: score }));
//   };

//   const flagForReview = () => {
//     if (!selected) return;
//     alert(`Segment ${selected.index} flagged for regulatory review.`);
//   };

//   const approveCompliant = () => {
//     if (!selected) return;
//     const text = selected.adapted?.trim().length ? selected.adapted : selected.source;
//     setCompliantById((prev) => ({ ...prev, [selected.id]: text }));
//   };

//   /** Complete Phase → next page */
//   const handleCompletePhase = () => {
//     navigate("/qualityIntelligence", {
//       state: {
//         projectName,
//         segments: segments.map((s) => ({
//           ...s,
//           complianceScore: scoreById[s.id] ?? s.complianceScore ?? null,
//           compliant: compliantById[s.id] ?? s.compliant ?? "",
//         })),
//       },
//     });
//   };

//   return (
//     <div className={`regulatory tm-app ${isFocusMode ? 'is-focus' : ''}`}>
//       {/* Sidebar */}
//          <aside className="tm-sidebar" aria-label="Workflow Phases">
//           {/* ✅ ADDED: Opacity fade when loading */}
//           {/* Hari-24/3 */}
//   <div className="tm-sidebar-progress" style={{ opacity: isProgressLoading ? 0.6 : 1, transition: 'opacity 0.3s' }}>
//     <div className="tm-progress-row">
//       <span className="tm-progress-label">Overall Progress</span>
//       {/* ✅ FIXED: Show "..." while loading instead of 0% */}
//       <span className="tm-progress-value">
//         {isProgressLoading ? "..." : `${overallPercent}%`}
//       </span>
//     </div>
//     <div className="tm-progress-sub">
//       {/* ✅ FIXED: Show "Syncing..." instead of 0 / 4 */}
//       {isProgressLoading ? "Loading..." : `${completedCount} / ${totalTargetPhases} phases completed`}
//     </div>
//     <div
//       className="tm-progress-bar"
//       role="progressbar"
//       aria-valuemin={0}
//       aria-valuemax={100}
//       aria-valuenow={overallPercent}
//     >
//       <div
//         className="tm-progress-fill"
//         style={{ width: `${overallPercent}%`, transition: 'width 0.4s ease-in-out' }}
//       />
//     </div>
//   </div>
 
//   <nav className="tm-phases">
//     {SIDEBAR_PHASES.map((p) => {
//       // isDone is true if the phase ID (P1, P2, etc) exists in the database/progressStore
//       const isDone = completedSet.has(p.id.toUpperCase());
//       const isActive = p.name === "Regulatory Compliance";
 
//       return (
//         <button
//           key={p.id}
//           className={`tm-phase-item ${isDone ? "done" : p.status} ${
//             isActive ? "is-active" : ""
//           }`}
//           aria-label={`Open ${p.name}`}
//           onClick={() => gotoPhase(p.id)}
//         >
//           {/* <span className={`tm-phase-icon ${p.iconClass}`} /> */}
//           <span className={`tm-phase-icon ${p.color || ''}`}>{p.icon}</span>
//           <span className="tm-phase-text">
//             <span className="tm-phase-title">{p.name}</span>
//             <span className="tm-phase-sub">{p.sub}</span>
//           </span>
//           {/* Checkmark appears only if the database confirms phase is complete */}
//           {/* {isDone && (
//             <span className="tm-phase-check" aria-hidden={true}>
//               ✓
//             </span>
//           )} */}

//           {/* Checkmark appears only if the database confirms phase is complete */}
//           {isDone && !isProgressLoading && (
//             <span className="tm-phase-check" aria-hidden={true}>
//               ✓
//             </span>
//           )}
//           {isActive && !isDone && !isProgressLoading && (
//             <span className="tm-phase-dot" aria-hidden={true} />
//           )}
//           {/* {isActive && !isDone && (
//             <span className="tm-phase-dot" aria-hidden={true} />
//           )} */}
//         </button>
//       );
//     })}
//   </nav>
// </aside>

//       {/* Main */}
//       <div className="tm-main">
//         {/* Header */}
//         <header className="tm-header">
//           <div className="tm-header-left">
//             <div className="tm-crumbs">
//               <button className="tm-crumb" onClick={() => navigate('/')}>
//                 <ArrowLeft size={14} className="h-1 w-1 mr-2" /> Main Hub
//               </button>
//               <span className="tm-divider" />
//               <button className="tm-crumb" onClick={() => navigate('/glocalizationHub')}>
//                 Glocalization Hub
//               </button>
//             </div>

//             <div className="tm-header-center">
//               <div className="tm-title-row">
//                 <h1 className="tm-page-title">{projectName}</h1>
//               </div>
//             </div>
//           </div>

//           <div className="tm-header-right">
//             <span className="tm-saved">
//               <CheckCircle2 size={12} className="h-1 w-1 text-green-600" />
//               Saved
//             </span>

//             <button className="tm-btn ghost tm-btn-icon">
//               <Save size={15} className="h-4 w-4 mr-2" /> Save
//             </button>

//             <button
//               className="tm-btn ghost tm-btn-icon"
//               onClick={toggleFocusMode}
//               aria-pressed={isFocusMode}
//               title={isFocusMode ? 'Exit focus (Esc)' : 'Enter focus (F)'}
//             >
//               {isFocusMode ? (
//                 <>
//                   <Minimize2 size={16} /> Exit
//                 </>
//               ) : (
//                 <>
//                   <Maximize2 size={16} /> Focus
//                 </>
//               )}
//             </button>
//           </div>
//         </header>

//         {/* Tabs bar */}
//         <section className="tm-tabs-bar">
//           <div className="tm-tabs">
//             <button
//               className={`tm-tab ${mainTab === "review" ? "is-active" : ""}`}
//               onClick={() => setMainTab("review")}
//             >
//               Compliance Review
//             </button>
//             <button
//               className={`tm-tab ${mainTab === "report" ? "is-active" : ""}`}
//               onClick={() => setMainTab("report")}
//             >
//               Compliance Report
//             </button>
//             <button
//               className={`tm-tab ${mainTab === "intel" ? "is-active" : ""}`}
//               onClick={() => setMainTab("intel")}
//             >
//               Regulatory Intelligence
//             </button>
//           </div>
//         </section>

//         {mainTab === "review" && (
//           <div>
//             <section className="tm-tabs-right" style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
//   <div className="tm-status-left">
//     <h2 className="tm-section-title">
//       <Shield size={20} className="h-5 w-5" />
//       Regulatory Compliance Workspace
//     </h2>
//     <p className="tm-section-sub">
//       Review culturally adapted content for regulatory compliance and market requirements
//     </p>
//   </div>
 
//   <div className="tm-actions-row" style={{ display: 'flex', alignItems: 'center', gap: '16px', marginLeft: 'auto' }}>
//     {/* 🆕 COMPLETE BUTTON: Positioned left of progress */}
//     <button
//       className="tm-btn tm-btn-primary"
//       onClick={handleCompleteCompliance}
//       style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 16px' }}
//     >
//       <CheckCircle size={18} />
//       Complete Phase
//     </button>
 
//     <div className="tm-progress-inline">
//       <span className="tm-progress-inline-label">Progress:</span>
//       {/* <span className="tm-progress-inline-value">
//         {completedCount === 4 ? "100%" : "75%"}
//       </span> */}
//       <span className="tm-progress-inline-value">
//                     {approvedCount} / {totalCount} approved
//                   </span>
//       <div className="tm-progress-inline-bar">
//         {/* Uses the overallPercent we set up in the previous step */}
//         <div
//           className="tm-progress-inline-fill"
//           style={{ width: `${localProgressPct}%`, transition: 'width 0.5s ease-in-out' }}
//         />
//       </div>
//     </div>
//   </div>
// </section>

//             {/* 🆕 NEW: LOADING GATE STARTS HERE */}
//             {isLoadingProject ? (
//               <div className="tm-workspace-loading" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '6rem 0', color: '#6B7280' }}>
//                 <Loader2 size={32} className="animate-spin mb-4 text-emerald-600" />
//                 <p>Syncing Data...</p>
//               </div>
//             ) : (
              
//             <section className="tm-workspace rc-workspace">
//               {/* Workspace grid */}

//               <div className="tm-card tm-left">
//                 <div className="tm-card-header">
//                   <h3 className="tm-card-title">Content Segments</h3>
//                   <span className="tm-light">{segments.length} segments to review</span>
//                 </div>

//                 <div className="tm-seg-list">
//                   {segments.map((seg) => {
//                     const isSelected = seg.id === selectedId;
//                     return (
//                       <button
//                         key={seg.id}
//                         className={`tm-seg-item ${isSelected ? "is-selected" : ""}`}
//                         onClick={() => setSelectedId(seg.id)}
//                         aria-label={`Open Segment ${seg.index}`}
//                       >
//                         <div className="tm-seg-item-top">
//                           <span className="tm-ci-index">Segment {seg.index}</span>
//                           <span className="tm-seg-state">
//                             {(() => {
//                               const o = segOverrides[seg.id] || {};
//                               const st = String(o.status ?? seg.status ?? "Pending").toLowerCase();
//                               return (
//                                 <span className="tm-seg-state">
//                                   {st === "approved" ? "Approved" : st === "flagged" ? "Flagged" : "Pending"}
//                                 </span>
//                               );
//                             })()}
//                           </span>
//                         </div>
//                         <div className="tm-seg-snippet">{seg.source}</div>
//                         <div className="tm-seg-meta-row">
//                           <span className="tm-seg-meta">{seg.words} words</span>
//                         </div>
//                       </button>
//                     );
//                   })}
//                   {segments.length === 0 && (
//                     <div className="tm-empty">No segment present to display.</div>
//                   )}
//                 </div>
//               </div>

//               <div className="tm-card tm-right">
//                 {selected && (
//                   <div className="tm-detail">

//                     {/* ===== 1) Source Text ===== */}
//                     <div className="rc-section">
//                       <div className="rc-section-head">
//                         <span className="rc-chip blue">Source Text</span>
//                       </div>

//                       <div className="rc-source-body">
//                         {selectedResolved.source}
//                       </div>
//                     </div>

//                     {/* ===== 2) Culturally Adapted Text (Phase 3) ===== */}
//                     <div className="rc-section">
//                       <div className="rc-section-head">
//                         <span className="rc-chip blue">Culturally Adapted Text (Phase 3)</span>

//                         <div className="rc-tools-inline">
//                           <span className="rc-score-pill">
//                             Score: {typeof scoreById[selected.id] === "number" ? `${scoreById[selected.id]}/100` : "—"}
//                           </span>
//                           <button
//                             className="rc-btn-check"
//                             onClick={openAnalysisModal}
//                             disabled={!selectedResolved.adapted?.trim() || isAnalyzing}
//                             title={
//                               selectedResolved.adapted?.trim()
//                                 ? "Open Compliance Analysis"
//                                 : "No adapted text to check"
//                             }
//                           >
//                             <Shield size={15} className="h-5 w-5" />
//                             {isAnalyzing ? "Analyzing…" : "Run Compliance Check"}
//                           </button>
//                         </div>
//                       </div>

//                       <div className="rc-adapted-card">
//                         <div className="rc-adapted-body">
//                           {selectedResolved.adapted?.trim()
//                             ? selectedResolved.adapted
//                             : <span className="rc-muted">— No adapted text —</span>}
//                         </div>
//                       </div>
//                     </div>

//                     {/* ===== 3) Regulatory Compliant Text ===== */}
//                     <div className="rc-section">
//                       <div className="rc-section-head">
//                         <span className="rc-chip green">Regulatory Compliant Text</span>

//                         <div className="rc-tools-inline">
//                           <button className="rc-link-flag" onClick={handleFlag}>
//                             <Flag size={12} className="h-4 w-4 mr-2" />
//                             Flag for Review
//                           </button>
//                           <button className="rc-btn-approve" onClick={handleApprove}>
//                             <CheckCircle size={12} className="h-4 w-4 mr-2" />
//                             Approve
//                           </button>
//                         </div>
//                       </div>

//                       <textarea
//                         // className="rc-textarea"
//                         // placeholder="Enter or edit the final compliant text here…"
//                         // value={compliantEditorValue}
//                         // onChange={(e) => setCompliantEditorValue(e.target.value)}
                        
//                         className="rc-textarea"
//   placeholder="Awaiting Regulatory Compliance text"
//   value={compliantEditorValue}
//   readOnly // This prevents the user from typing or deleting text
//                       />
//                     </div>

//                   </div>
//                 )}
//               </div>
//             </section>
          
        
//         )}
//         </div>
//         )}

//         {mainTab === "report" && (
//           <div className="rc-report">
//             {/* SUMMARY CARDS */}
//             <div className="rc-report-cards">
//               <div className="rc-report-card">
//                 <div className="rc-report-card-label">Segments Approved</div>
//                 <div className="rc-report-card-value">
//                   {approvedCount}/{totalCount}
//                 </div>
//               </div>
//               <div className="rc-report-card">
//                 <div className="rc-report-card-label">Critical Issues</div>
//                 <div className="rc-report-card-value danger">{criticalIssuesCount}</div>
//               </div>
//               <div className="rc-report-card">
//                 <div className="rc-report-card-label">Avg Compliance Score</div>
//                     <div className="rc-report-card-value"> {overallComplianceScoreFromModal != null ? `${overallComplianceScoreFromModal}%` : "—"}</div>
//               </div>
//               <div className="rc-report-card">
//                 <div className="rc-report-card-label">Total Changes</div>
//                 <div className="rc-report-card-value">{totalChanges}</div>
//               </div>
//             </div>

//             {/* FINAL REGULATORY-COMPLIANT TRANSLATION */}
//             <div className="rc-card rc-report-list">
//               <div className="rc-card-head">
//                 <div className="rc-card-title">Final Regulatory-Compliant Translation</div>
//                 <div className="rc-card-actions">
//                   <button className="rc-btn outline" onClick={exportReport}>
//                     Export Report
//                   </button>
//                 </div>
//               </div>

//               <div className="rc-report-items">
//                 {segments.length === 0 && (
//                   <div className="rc-empty">No segments found.</div>
//                 )}

//                 {segments.map((seg) => {
//                   const adapted = (seg.adapted || "").trim()
//                     ? seg.adapted
//                     : "— No adapted text —";
//                   return (
//                     <div className="rc-report-item" key={`rep-${seg.id}`}>
//                       <div className="rc-report-item-head">
//                         <span className="rc-report-item-index">Segment {seg.index}</span>
//                       </div>
//                       <div className="rc-report-item-body">
//                         <pre className="rc-pre">{adapted}</pre>
//                       </div>
//                     </div>
//                   );
//                 })}
//               </div>
//             </div>
//           </div>
//         )}

//         {mainTab === "intel" && (
//           <div className="rc-intel">
//             {/* DASHBOARD HEADER */}
//             <div className="rc-intel-head">
//               <div className="rc-intel-title">Regulatory Intelligence Dashboard</div>
//               <span className="rc-chip small success">Compliance: {avgCompliance}%</span>
//             </div>

//             {/* KPI CARDS */}
//             <div className="rc-intel-kpis">
//               <div className="rc-intel-kpi">
//                 <div className="rc-intel-kpi-top">Overall Compliance</div>
//                 <div className="rc-intel-kpi-value">{avgCompliance}%</div>
//               </div>
//               <div className="rc-intel-kpi">
//                 <div className="rc-intel-kpi-top">Passed Rules</div>
//                 <div className="rc-intel-kpi-value">{approvedCount}</div>
//               </div>
//               <div className="rc-intel-kpi">
//                 <div className="rc-intel-kpi-top">Warnings</div>
//                 <div className="rc-intel-kpi-value">{flaggedCount}</div>
//               </div>
//               <div className="rc-intel-kpi">
//                 <div className="rc-intel-kpi-top">Critical Issues</div>
//                 <div className="rc-intel-kpi-value danger">{criticalIssuesCount}</div>
//               </div>
//             </div>

//             {/* INNER TABS */}
//             <IntelInnerTabs
//               locale={getTargetLang(therapyArea)}
//               overallPct={avgCompliance}
//             />
//           </div>
//         )}
//       </div>

//       {/* ================== ANALYSIS POPUP ================== */}
//       {isAnalysisModalOpen && selectedResolved && (
//         <div
//           className="rcm-modal-backdrop"
//           role="dialog"
//           aria-modal="true"
//           aria-label={`Regulatory Compliance Analysis - Segment ${selectedResolved.index}`}
//           onClick={(e) => {
//             if (e.target === e.currentTarget) setIsAnalysisModalOpen(false);
//           }}
//         >
//           <div className="rcm-modal">
//             {/* HEADER */}
//             <div className="rcm-modal__header">
//               <div className="rcm-modal__title">
//                 <span className="rcm-bullet" />
//                 Regulatory Compliance Analysis - Segment {selectedResolved.index}
//               </div>
//               <div className="rcm-modal__chips">
//                 <span className={`rcm-chip risk ${analysisData.risk.toLowerCase()}`}>
//                   {analysisData.risk[0] + analysisData.risk.slice(1).toLowerCase()} Risk
//                 </span>
//                 <span className="rcm-chip score">Score: {analysisData.score}%</span>
//               </div>
//             </div>

//             {/* TABS */}
//             <div className="rcm-tabs">
//               <button
//                 className={activeTab === "issues" ? "active" : ""}
//                 onClick={() => setActiveTab("issues")}
//               >
//                 Compliance Issues{" "}
//                 <span className="rc-tab-badge">
//                   {analysisData.criticalIssues.length + n8nCritical.length + n8nRecs.length}
//                 </span>
//               </button>
//               <button
//                 className={activeTab === "pre" ? "active" : ""}
//                 onClick={() => setActiveTab("pre")}
//               >
//                 Pre-Approved Content
//               </button>
//               <button
//                 className={activeTab === "templates" ? "active" : ""}
//                 onClick={() => setActiveTab("templates")}
//               >
//                 Regulatory Templates
//               </button>
//             </div>

//             {/* BODY */}
//             <div className="rcm-modal__body">
//               {/* Overall score row */}
//               <div className="rcm-overall">
//                 <div className="rcm-overall__left">
//                   <div className="rcm-overall__label">Overall Compliance Score</div>
//                     <div className="rcm-overall__value">   {analysisData.score !== null ? `${analysisData.score}/100` : ""} </div>
//                     </div>
//                 <div className="rcm-overall__right">
//                   <div className="rcm-overall__sub">Risk Level</div>
//                   <div className={`rcm-overall__risk ${analysisData.risk.toLowerCase()}`}>
//                     {analysisData.risk}
//                   </div>
//                 </div>
//               </div>

//               {/* Critical Issues */}
//               <div className="rcm-section-title">
//                 <span className="rcm-icon warn">!</span>
//                 Critical Issues – Must Change{" "}
//                 <span className="rc-tab-badge">
//                   {analysisData.criticalIssues.length + n8nCritical.length}
//                 </span>
//               </div>

//               {/* Existing (kept empty) critical issues structure */}
//               {analysisData.criticalIssues.map((it) => {
//                 const mlrMatch = currentSegOverride?.mlr?.rule === it.text;
//                 return (
//                   <div key={it.id} className="rcm-issue rcm-issue--critical">
//                     <div className="rcm-issue__content">{it.text}</div>

//                     {!mlrMatch && (
//                       <div className="rcm-issue__actions">
//                         <button className="btn success" onClick={() => applyCompliantSuggestion(it.text)}>
//                           ✓ Accept &amp; Apply Changes
//                         </button>
//                         <button className="btn outline" onClick={() => openMlrModal(it.text)}>
//                           ⓘ Request MLR Exception
//                         </button>
//                         <button className="btn danger" onClick={() => openBlockModal(it.text)}>
//                           ⛔ Mark as Blocking
//                         </button>
//                       </div>
//                     )}

//                     {mlrMatch && (
//                       <div className="rcm-logged-note">
//                         <div className="rcm-logged-note__label">Decision Reasoning:</div>
//                         <textarea
//                           className="rcm-logged-note__textarea"
//                           value={currentSegOverride.mlr.reasoning}
//                           readOnly
//                         />
//                         <div className="rcm-logged-note__meta">
//                           Logged at: {new Date(currentSegOverride.mlr.at).toLocaleString()}
//                         </div>
//                       </div>
//                     )}
//                   </div>
//                 );
//               })}

//               {/* n8n loading indicator */}
//               {n8nLoading && (
//                 <div className="rcm-issue rcm-issue--critical" key="n8n-loading">
//                   <div className="rcm-issue__content">Analyzing with AI…</div>
//                 </div>
//               )}

//               {/* n8n error (appended, non-blocking) */}
//               {!n8nLoading && n8nError && (
//                 <div className="rcm-issue rcm-issue--critical" key="n8n-error">
//                   <div className="rcm-issue__content">{n8nError}</div>
//                 </div>
//               )}

//               {/* n8n results under Critical Issues */}
//               {!n8nLoading &&
//                 !n8nError &&
//                 n8nCritical.map((it) => {
//                   const mlrMatch = currentSegOverride?.mlr?.rule === it.text;
//                   return (
//                     <div key={it.id} className="rcm-issue rcm-issue--critical">
//                       <div className="rcm-issue__content">{it.text}</div>

//                       {!mlrMatch && (
//                         <div className="rcm-issue__actions">
//                           <button className="btn success" onClick={() => applyCompliantSuggestion(it.text)}>
//                             ✓ Accept &amp; Apply Changes
//                           </button>
//                           <button className="btn outline" onClick={() => openMlrModal(it.text)}>
//                             ⓘ Request MLR Exception
//                           </button>
//                           <button className="btn danger" onClick={() => openBlockModal(it.text)}>
//                             ⛔ Mark as Blocking
//                           </button>
//                         </div>
//                       )}

//                       {mlrMatch && (
//                         <div className="rcm-logged-note">
//                           <div className="rcm-logged-note__label">Decision Reasoning:</div>
//                           <textarea
//                             className="rcm-logged-note__textarea"
//                             value={currentSegOverride.mlr.reasoning}
//                             readOnly
//                           />
//                           <div className="rcm-logged-note__meta">
//                             Logged at: {new Date(currentSegOverride.mlr.at).toLocaleString()}
//                           </div>
//                         </div>
//                       )}
//                     </div>
//                   );
//                 })}

//               {/* Recommended Changes (ONLY from n8n) */}
//               <div className="rcm-section-title">
//                 <span className="rcm-icon info">○</span>
//                 Recommended Changes{" "}
//                 <span className="rc-tab-badge">
//                   {n8nRecs.length}
//                 </span>
//               </div>

//               {!n8nLoading &&
//                 !n8nError &&
//                 n8nRecs.map((it) => {
//                   const deferredMatch = currentSegOverride?.mlrDefer?.rule === it.text;
//                   const riskMatch = currentSegOverride?.acceptedRisk?.rule === it.text;
//                   const hasDecision = deferredMatch || riskMatch;

//                   return (
//                     <div key={it.id} className="rcm-issue rcm-issue--reco">
//                       <div className="rcm-issue__content">{it.text}</div>

//                       {!hasDecision && (
//                         <div className="rcm-issue__actions">
//                           <button
//                             className="btn hollow-success"
//                             onClick={() => acceptRecommendation(it.text)}
//                           >
//                             ✓ Accept Recommendation
//                           </button>
//                           <button
//                             className="btn outline-blue"
//                             onClick={() => openDeferModal(it.text)}
//                           >
//                             ☐ Defer to MLR Review
//                           </button>
//                           <button className="btn ghost" onClick={() => openRiskModal(it.text)}>
//                             Accept Risk &amp; Skip
//                           </button>
//                         </div>
//                       )}

//                       {deferredMatch && (
//                         <div className="rcm-logged-note">
//                           <div className="rcm-logged-note__label">Decision Reasoning:</div>
//                           <textarea
//                             className="rcm-logged-note__textarea"
//                             value={currentSegOverride.mlrDefer.reasoning}
//                             readOnly
//                           />
//                           <div className="rcm-logged-note__meta">
//                             Logged at: {new Date(currentSegOverride.mlrDefer.at).toLocaleString()}
//                           </div>
//                         </div>
//                       )}

//                       {riskMatch && (
//                         <div className="rcm-logged-note">
//                           <div className="rcm-logged-note__label">Decision Reasoning:</div>
//                           <textarea
//                             className="rcm-logged-note__textarea"
//                             value={currentSegOverride.acceptedRisk.reasoning}
//                             readOnly
//                           />
//                           <div className="rcm-logged-note__meta">
//                             Logged at: {new Date(currentSegOverride.acceptedRisk.at).toLocaleString()}
//                           </div>
//                         </div>
//                       )}
//                     </div>
//                   );
//                 })}
//             </div>

//             {/* FOOTER */}
//             <div className="rcm-modal__footer">
//               <button
//                 className={`btn outline ${isReAnalyzing ? "is-loading" : ""}`}
//                 onClick={openAnalysisModal}//27_03_sanju
//                 disabled={isReAnalyzing || isReAnalyzeDisabled}
//               >
//                 {isReAnalyzing ? "Re-analyzing…" : "Re-Analyze with AI"}
//               </button>
//               <div className="rcm-footer-right">
//                 <button className="btn success" onClick={markCompliantFromModal}>
//                   ✓ Mark as Compliant
//                 </button>
//                 <button
//                   className="btn ghost"
//                   onClick={() => setIsAnalysisModalOpen(false)}
//                 >
//                   Close
//                 </button>
//               </div>
//             </div>
//           </div>
//         </div>
//       )}

//       {/* ================== Request MLR Exception POPUP ================== */}
//       {isMlrOpen && (
//         <div
//           className="mlr-modal-backdrop"
//           role="dialog"
//           aria-modal="true"
//           aria-label="Request MLR Exception"
//           onClick={(e) => {
//             if (e.target === e.currentTarget) setIsMlrOpen(false);
//           }}
//         >
//           <div className="mlr-modal">
//             {/* Header */}
//             <div className="mlr-header">
//               <div className="mlr-title">
//                 <span className="mlr-warn-icon">⚠</span> Request MLR Exception
//               </div>
//               <button
//                 className="mlr-close"
//                 aria-label="Close"
//                 onClick={() => setIsMlrOpen(false)}
//               >
//                 ✕
//               </button>
//             </div>

//             {/* Subtext */}
//             <div className="mlr-subtext">
//               Explain why this critical compliance issue requires an exception. This will
//               be escalated to the Medical Legal Regulatory team for approval.
//             </div>

//             {/* Rule */}
//             <div className="mlr-label">Rule</div>
//             <div className="mlr-rule-box">{mlrRuleText || "No rule text available."}</div>

//             {/* Reasoning */}
//             <div className="mlr-label req">Reasoning *</div>
//             <textarea
//               className={`mlr-textarea ${mlrTouched && !mlrReason.trim() ? "is-invalid" : ""}`}
//               placeholder="Enter detailed reasoning for this decision..."
//               value={mlrReason}
//               onChange={(e) => setMlrReason(e.target.value)}
//               onBlur={() => setMlrTouched(true)}
//             />

//             <div className="mlr-hint">This reasoning will be logged for audit purposes.</div>

//             {/* Footer */}
//             <div className="mlr-footer">
//               <button className="btn ghost" onClick={() => setIsMlrOpen(false)}>
//                 Cancel
//               </button>
//               <button
//                 className="btn primary"
//                 onClick={submitMlr}
//                 disabled={!mlrReason.trim() || mlrSubmitting}
//               >
//                 {mlrSubmitting ? "Submitting…" : "Submit"}
//               </button>
//             </div>
//           </div>
//         </div>
//       )}

//       {/* ================== Defer to MLR Review POPUP ================== */}
//       {isDeferOpen && (
//         <div
//           className="mlr-modal-backdrop"
//           role="dialog"
//           aria-modal="true"
//           aria-label="Defer to MLR Review"
//           onClick={(e) => {
//             if (e.target === e.currentTarget) setIsDeferOpen(false);
//           }}
//         >
//           <div className="mlr-modal">
//             {/* Header */}
//             <div className="mlr-header">
//               <div className="mlr-title">
//                 <span className="mlr-warn-icon">⚠</span> Defer to MLR Review
//               </div>
//               <button
//                 className="mlr-close"
//                 aria-label="Close"
//                 onClick={() => setIsDeferOpen(false)}
//               >
//                 ✕
//               </button>
//             </div>

//             {/* Subtext */}
//             <div className="mlr-subtext">
//               Provide context for the MLR team to review during the approval process.
//               Explain why manual review is needed.
//             </div>

//             {/* Rule */}
//             <div className="mlr-label">Rule</div>
//             <div className="mlr-rule-box">{deferRuleText || "No rule text available."}</div>

//             {/* Reasoning */}
//             <div className="mlr-label req">Reasoning *</div>
//             <textarea
//               className={`mlr-textarea ${
//                 deferTouched && !deferReason.trim() ? "is-invalid" : ""
//               }`}
//               placeholder="Enter detailed reasoning for this decision..."
//               value={deferReason}
//               onChange={(e) => setDeferReason(e.target.value)}
//               onBlur={() => setDeferTouched(true)}
//             />

//             <div className="mlr-hint">This reasoning will be logged for audit purposes.</div>

//             {/* Footer */}
//             <div className="mlr-footer">
//               <button className="btn ghost" onClick={() => setIsDeferOpen(false)}>
//                 Cancel
//               </button>
//               <button
//                 className="btn primary"
//                 onClick={submitDefer}
//                 disabled={!deferReason.trim() || deferSubmitting}
//               >
//                 {deferSubmitting ? "Submitting…" : "Submit"}
//               </button>
//             </div>
//           </div>
//         </div>
//       )}

//       {/* ================== Accept Risk & Skip POPUP ================== */}
//       {isRiskOpen && (
//         <div
//           className="mlr-modal-backdrop"
//           role="dialog"
//           aria-modal="true"
//           aria-label="Accept Risk &amp; Skip"
//           onClick={(e) => {
//             if (e.target === e.currentTarget) setIsRiskOpen(false);
//           }}
//         >
//           <div className="mlr-modal">
//             {/* Header */}
//             <div className="mlr-header">
//               <div className="mlr-title">
//                 <span className="mlr-warn-icon">⚠</span> Accept Risk &amp; Skip
//               </div>
//               <button
//                 className="mlr-close"
//                 aria-label="Close"
//                 onClick={() => setIsRiskOpen(false)}
//               >
//                 ✕
//               </button>
//             </div>

//             {/* Subtext */}
//             <div className="mlr-subtext">
//               Document your decision to skip this recommendation. Include your rationale
//               and any risk assessment considerations.
//             </div>

//             {/* Rule */}
//             <div className="mlr-label">Rule</div>
//             <div className="mlr-rule-box">{riskRuleText || "No rule text available."}</div>

//             {/* Reasoning */}
//             <div className="mlr-label req">Reasoning *</div>
//             <textarea
//               className={`mlr-textarea ${
//                 riskTouched && !riskReason.trim() ? "is-invalid" : ""
//               }`}
//               placeholder="Enter detailed reasoning for this decision..."
//               value={riskReason}
//               onChange={(e) => setRiskReason(e.target.value)}
//               onBlur={() => setRiskTouched(true)}
//             />

//             <div className="mlr-hint">This reasoning will be logged for audit purposes.</div>

//             {/* Footer */}
//             <div className="mlr-footer">
//               <button className="btn ghost" onClick={() => setIsRiskOpen(false)}>
//                 Cancel
//               </button>
//               <button
//                 className="btn primary"
//                 onClick={submitRisk}
//                 disabled={!riskReason.trim() || riskSubmitting}
//               >
//                 {riskSubmitting ? "Submitting…" : "Submit"}
//               </button>
//             </div>
//           </div>
//         </div>
//       )}

//       {/* ================== Mark as Blocking POPUP ================== */}
//       {isBlockOpen && (
//         <div
//           className="mlr-modal-backdrop"
//           role="dialog"
//           aria-modal="true"
//           aria-labelledby="blockTitle"
//           onClick={(e) => {
//             if (e.target === e.currentTarget) setIsBlockOpen(false);
//           }}
//         >
//           <div className="block-modal">
//             <div className="block-header">
//               <div className="block-title" id="blockTitle">
//                 <span className="block-warn-circ">i</span>
//                 Blocking Decision
//               </div>
//               <span className="block-badge">Blocking</span>
//               <button
//                 className="block-close"
//                 aria-label="Close"
//                 onClick={() => setIsBlockOpen(false)}
//               >
//                 ✕
//               </button>
//             </div>

//             <div className="block-card">
//               <div className="block-icon">!</div>
//               <div className="block-text">{blockRuleText || "No rule text available."}</div>
//             </div>

//             <div className="block-reason-wrap">
//               <div className="block-reason-label">Decision Reasoning:</div>
//               <textarea
//                 className={`block-reason ${blockTouched && !blockReason.trim() ? "is-invalid" : ""}`}
//                 value={blockReason}
//                 onChange={(e) => setBlockReason(e.target.value)}
//                 onBlur={() => setBlockTouched(true)}
//                 placeholder="Add any additional context for why this is blocking..."
//               />
//             </div>

//             <div className="block-footer">
//               <button className="btn ghost" onClick={() => setIsBlockOpen(false)}>
//                 Cancel
//               </button>
//               <button
//                 className="btn danger"
//                 onClick={submitBlock}
//                 disabled={!blockReason.trim() || blockSubmitting}
//                 title={!blockReason.trim() ? "Reasoning is required" : "Submit blocking decision"}
//               >
//                 {blockSubmitting ? "Marking…" : "Mark as Blocking"}
//               </button>
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// }

// /* ================== Small Component: Regulatory Intelligence Inner Tabs ================== */
// function IntelInnerTabs({ locale = "DE", overallPct = 100 }) {
//   const [tab, setTab] = useState("matrix"); // matrix | pre | templates | realtime

//   return (
//     <div className="intel-tabs">
//       <div className="intel-tabbar">
//         <button className={tab === "matrix" ? "active" : ""} onClick={() => setTab("matrix")}>
//           Compliance Matrix
//         </button>
//         <button className={tab === "pre" ? "active" : ""} onClick={() => setTab("pre")}>
//           Pre-Approved Content
//         </button>
//         <button className={tab === "templates" ? "active" : ""} onClick={() => setTab("templates")}>
//           Templates
//         </button>
//         <button className={tab === "realtime" ? "active" : ""} onClick={() => setTab("realtime")}>
//           Real-Time Validator
//         </button>
//       </div>

//       {tab === "matrix" && (
//         <div className="intel-panel">
//           <div className="intel-matrix-row">
//             <div className="intel-matrix-label">{locale}</div>
//             <div className="intel-matrix-bar" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={overallPct}>
//               <div className="intel-matrix-fill" style={{ width: `${overallPct}%` }} />
//               <span className="intel-matrix-pct">{overallPct}%</span>
//             </div>
//           </div>
//         </div>
//       )}

//       {tab === "pre" && (
//         <div className="intel-panel">
//           <div className="intel-placeholder">
//             No pre-approved content linked. Use your brand library to attach items.
//           </div>
//         </div>
//       )}

//       {tab === "templates" && (
//         <div className="intel-panel">
//           <div className="intel-templates">
//             <div className="intel-template-card">
//               <div className="intel-template-title">HWG Disclosure Boilerplate</div>
//               <div className="intel-template-sub">Localized: {locale}</div>
//               <button className="rc-btn tiny">Insert</button>
//             </div>
//             <div className="intel-template-card">
//               <div className="intel-template-title">Social Media Risk Footnote</div>
//               <div className="intel-template-sub">Localized: {locale}</div>
//               <button className="rc-btn tiny">Insert</button>
//             </div>
//           </div>
//         </div>
//       )}

//       {tab === "realtime" && (
//         <div className="intel-panel">
//           <div className="intel-validator">
//             <div className="intel-validator-head">
//               Real-Time Validator
//               <span className="rc-chip small">Beta</span>
//             </div>
//             <div className="intel-validator-bar" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={overallPct}>
//               <div className="intel-validator-fill" style={{ width: `${overallPct}%` }} />
//               <span className="intel-validator-pct">{overallPct}%</span>
//             </div>
//             <div className="intel-placeholder small">Live checks are green. No critical issues.</div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// }

// // /* Sidebar phases */
// // const SIDEBAR_PHASES = [
// //   { id: 'P1', name: "Global Context Capture", sub: "Source content analysis", status: "done", iconClass: "icon-context" },
// //   { id: 'P2', name: "Smart TM Translation", sub: "AI-powered translation", status: "done", iconClass: "icon-translation" },
// //   { id: 'P3', name: "Cultural Intelligence", sub: "Cultural adaptation", status: "done", iconClass: "icon-culture" },
// //   { id: 'P4', name: "Regulatory Compliance", sub: "Compliance validation", status: "active", iconClass: "icon-compliance" },
// //   { id: 'P5', name: "Quality Intelligence", sub: "Quality assurance", status: "todo", iconClass: "icon-quality" },
// //   { id: 'P6', name: "DAM Integration", sub: "Asset packaging", status: "todo", iconClass: "icon-dam" },
// //   { id: 'P7', name: "Integration Lineage", sub: "System integration", status: "todo", iconClass: "icon-integration" },
// // ];

// const SIDEBAR_PHASES = [
//   {
//     id: 'P1',
//     name: "Global Context Capture",
//     sub: "Source content analysis",
//     status: "done",
//     icon: <Globe size={18} />,
//     color: 'is-blue'
//   },
//   {
//     id: 'P2',
//     name: "Smart TM Translation",
//     sub: "AI-powered translation",
//     status: "done",
//     icon: <Languages size={18} />,
//     color: 'is-purple'
//   },
//   {
//     id: 'P3',
//     name: "Cultural Intelligence",
//     sub: "Cultural adaptation",
//     status: "done",
//     icon: <MessageSquare size={18} />,
//     color: 'is-green'
//   },
//   {
//     id: 'P4',
//     name: "Regulatory Compliance",
//     sub: "Compliance validation",
//     status: "active",
//     icon: <Shield size={18} />,
//     color: 'is-orange'
//   },
//   {
//     id: 'P5',
//     name: "Quality Intelligence",
//     sub: "Quality assurance",
//     status: "todo",
//     icon: <CheckCircleIcon size={18} />,
//     color: 'is-cyan'
//   },
//   {
//     id: 'P6',
//     name: "DAM Integration",
//     sub: "Asset packaging",
//     status: "todo",
//     icon: <Box size={18} />,
//     color: 'is-pink'
//   },
//   {
//     id: 'P7',
//     name: "Integration Lineage",
//     sub: "System integration",
//     status: "todo",
//     icon: <MessageSquare size={18} />,
//     color: 'is-violet'
//   },
// ];
 
/* New code abhirup_01_04*/

import React, { useMemo, useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import "../App.css";
import { getProject, updateProjectMeta, markPhaseComplete, computeProgress } from '../lib/progressStore';
import { usePhaseNavigation } from "./PhaseNav.jsx";
import { buildRegulatoryCompliancePrompt } from '../prompts/regulatoryCompliancePrompt';
import "./css/Regulatory.css";
import {
  ArrowLeft, Save, ArrowRight, Flag, Upload, FileText, CheckCircle2, Maximize2, BarChart3, FileDown,
  Brain, Shield, Minimize2, Users, Stethoscope, Edit3, Plus, X, Pill, Unlock, CheckCircle, TrendingUp,
  Languages, Loader2, Sparkles, Lock, Box, MessageSquare, Globe, CheckCircle as CheckCircleIcon
} from 'lucide-react';

/**
 * Regulatory Compliance Hub (Destination page)
 * - 3 Tabs: Compliance Review | Compliance Report | Regulatory Intelligence
 * - Two cards: Left segments, Right detail (Source | Adapted | Compliant)
 */
export default function RegulatoryComplianceHub({
  projectName: projectNameProp = "No project name to display",
  therapyArea = "Respiratory · DE",
  progressItems: progressItemsProp = { approved: 0, total: 15 },
  segments: segmentsProp = [],
}) {
  const { state } = useLocation();
  const navigate = useNavigate();

  const projectId = state?.projectId;
  const [projectRec, setProjectRec] = useState(null);
  const totalTargetPhases = 4; // Define this clearly at the top

  // 🆕 NEW: Add loading state. Starts true if we have a project.
  const [isLoadingProject, setIsLoadingProject] = useState(!!projectId);
 
  const refreshGlobalProgress = async () => {
    if (projectId) {
      const p = await getProject(projectId);
      setProjectRec(p);
      setIsLoadingProject(false);
    }else {
      setIsLoadingProject(false);
    }
  };
 
  useEffect(() => {
    refreshGlobalProgress();
    window.addEventListener('glocal_progress_updated', refreshGlobalProgress);
    return () => window.removeEventListener('glocal_progress_updated', refreshGlobalProgress);
  }, [projectId]);
 
  // Wrap in useMemo for performance and safety
  // const progressData = useMemo(() => {
  //   // If project hasn't loaded, default to 75% (since we are in Phase 4)
  //   if (!projectRec) {
  //     return { count: 3, percent: 75, set: new Set(['P1', 'P2', 'P3']) };
  //   }
 
  //   const { completedSet } = computeProgress(projectRec);
  //   const count = Math.min(completedSet.size, totalTargetPhases);
  //   const percent = Math.round((count / totalTargetPhases) * 100);
 
  //   return { count, percent, set: completedSet };
  // }, [projectRec]);
  // Wrap in useMemo for performance and safety
  // const progressData = useMemo(() => {
  //   // 🆕 1. Check local storage synchronously to stop the progress bar jumping
  //   let recToUse = projectRec;
  //   if (!recToUse && projectId) {
  //     const db = JSON.parse(localStorage.getItem('glocal_progress_v1') || '{}');
  //     recToUse = db[projectId];
  //   }

  //   // 2. Safe fallback if completely empty
  //   if (!recToUse) {
  //     return { count: 3, percent: 'Loading...' , set: new Set(['P1', 'P2', 'P3']) };
  //   }
 
  //   const { completedSet } = computeProgress(recToUse);
  //   const count = Math.min(completedSet.size, totalTargetPhases);
  //   const percent = Math.round((count / totalTargetPhases) * 100);
 
  //   return { count, percent, set: completedSet };
  // }, [projectRec, projectId]);
 
  // // Unified variable names to match all your JSX parts
  // const completedCount = progressData.count;
  // const overallPercent = progressData.percent;
  // const completedSet   = progressData.set;
 
  // // Aliases to prevent "ReferenceError" in different parts of your file
  // const overallPct  = overallPercent;
  // const progressPct = overallPercent;

  // ✅ 1. UPDATED: Provide the isProgressLoading state
  //Hari-24/3
  // const progressData = useMemo(() => {
  //   if (!projectRec) {
  //     // Return a temporary loading state while the database is fetching
  //     return { count: 0, percent: 0, set: new Set(), isProgressLoading: true };
  //   }
 
  //   const { completedSet } = computeProgress(projectRec);
  //   const count = Math.min(completedSet.size, totalTargetPhases);
  //   const percent = Math.round((count / totalTargetPhases) * 100);
 
  //   return { count, percent, set: completedSet, isProgressLoading: false };
  // }, [projectRec]);
 
  // // Unified variable names to match all your JSX parts
  // const completedCount = progressData.count;
  // const overallPercent = progressData.percent;
  // const completedSet   = progressData.set;
  // const isProgressLoading = progressData.isProgressLoading; // 🆕 Extracted safely!
 
  // // Aliases to prevent "ReferenceError" in different parts of your file
  // const overallPct  = overallPercent;
  // const progressPct = overallPercent;

  //Kathir-25/3-------------------------------------
  // const progressData = useMemo(() => {
  //   let recToUse = projectRec;
 
  //   // Synchronous fallback: If React state (projectRec) hasn't loaded yet,
  //   // immediately check localStorage to prevent the progress bar from flickering.
  //   if (!recToUse && projectId) {
  //     try {
  //       const rawDb = localStorage.getItem('glocal_progress_v1');
  //       const db = JSON.parse(rawDb || '{}');
  //       recToUse = db[projectId];
  //     } catch (e) {
  //       console.error("Error reading progress from localStorage:", e);
  //     }
  //   }
 
  //   // If still no record exists, return the temporary loading state
  //   if (!recToUse) {
  //     return { count: 0, percent: 0, set: new Set(), isProgressLoading: true };
  //   }
 
  //   // Calculate progress based on the guaranteed latest data
  //   const { completedSet } = computeProgress(recToUse);
  //   const count = Math.min(completedSet.size, totalTargetPhases);
  //   const percent = Math.round((count / totalTargetPhases) * 100);
 
  //   return { count, percent, set: completedSet, isProgressLoading: !projectRec };
  // }, [projectRec, projectId]); // Added projectId to dependencies
 
  // // Unified variable names to match all your JSX parts
  // const completedCount = progressData.count;
  // const overallPercent = progressData.percent;
  // const completedSet   = progressData.set;
  // const isProgressLoading = progressData.isProgressLoading;
 
  // // Aliases to prevent "ReferenceError" in different parts of your file
  // const overallPct  = overallPercent;
  // const progressPct = overallPercent;

  // ✅ UPGRADED UNIVERSAL CACHE
  const progressData = useMemo(() => {
    let recToUse = projectRec;
    const isRecEmpty = !recToUse || Object.keys(recToUse).length === 0;

    // Synchronous fallback: If React state hasn't loaded or is empty, grab from cache
    if (isRecEmpty && projectId) {
      try {
        const rawDb = localStorage.getItem('glocal_progress_v1');
        const db = JSON.parse(rawDb || '{}');
        if (db[projectId]) {
            recToUse = db[projectId];
        }
      } catch (e) {
        console.error("Error reading progress from localStorage:", e);
      }
    }

    // If still no record exists anywhere
    if (!recToUse || Object.keys(recToUse).length === 0) {
      return { 
        count: 0, 
        percent: 0, 
        set: new Set(), 
        isProgressLoading: isRecEmpty 
      };
    }

    // Calculate progress based on the guaranteed latest data
    const { completedSet } = computeProgress(recToUse);
    const count = Math.min(completedSet.size, totalTargetPhases);

    return {
      count: count,
      percent: Math.round((count / totalTargetPhases) * 100),
      set: completedSet,
      isProgressLoading: !projectRec || Object.keys(projectRec).length === 0
    };
  }, [projectRec, projectId]);

  // Unified variable names to match all your JSX parts
  const completedCount = progressData.count;
  const overallPercent = progressData.percent;
  const completedSet   = progressData.set;
  const isProgressLoading = progressData.isProgressLoading;
 
  // Aliases to prevent "ReferenceError" in different parts of your file
  const overallPct  = overallPercent;
  const progressPct = overallPercent;
  const country = state?.country ?? null;
  console.log(country);
  const projectName = state?.projectName ?? projectNameProp;
  // Sanju - 01/04/2026 — wrap gotoPhase to persist P4 data before navigating away (bottom-to-top fix)
  const gotoPhaseRaw = usePhaseNavigation(projectId, projectName, country);
  // Sanju - 01/04/2026 — async wrapper saves P4 segments to DB before sidebar navigation
  const gotoPhase = async (phaseId) => {
    if (projectId && hasHydrated) {
      try {
        await updateProjectMeta(projectId, { segmentsP4: buildP4Segments() });
      } catch (e) {
        console.warn('Sanju - 01/04/2026: Failed to persist P4 before navigation:', e);
      }
    }
    gotoPhaseRaw(phaseId);
  };

  // const projectRec = useMemo(() => getProject(projectId), [projectId]);

  // const persistedSegmentsP4 = useMemo(
  //   () =>
  //     (projectRec?.meta?.segmentsP4 && Array.isArray(projectRec.meta.segmentsP4))
  //       ? projectRec.meta.segmentsP4
  //       : [],
  //   [projectRec]
  // );

  // const persistedSegmentsP3 = useMemo(
  //   () => (projectRec?.meta?.segmentsP3 && Array.isArray(projectRec.meta.segmentsP3))
  //     ? projectRec.meta.segmentsP3 : [],
  //   [projectRec]
  // );
  // const persistedSegmentsP2 = useMemo(
  //   () => (projectRec?.meta?.segmentsP2 && Array.isArray(projectRec.meta.segmentsP2))
  //     ? projectRec.meta.segmentsP2 : [],
  //   [projectRec]
  // );


 

 
  // ✅ Wrapped in useMemo to stop the infinite loop!
  const persistedSegmentsP4 = useMemo(() => projectRec?.meta?.segmentsP4 || [], [projectRec]);
  const persistedSegmentsP3 = useMemo(() => projectRec?.meta?.segmentsP3 || [], [projectRec]);
  const persistedSegmentsP2 = useMemo(() => projectRec?.meta?.segmentsP2 || [], [projectRec]);

  // --- Focus mode state (unique key for Cultural page) ---
  const [isFocusMode, setIsFocusMode] = useState(() => {
    const v = localStorage.getItem('ci_focus_mode');
    return v === 'true';
  });

  const toggleFocusMode = () => setIsFocusMode(prev => !prev);

  // persist on change
  useEffect(() => {
    localStorage.setItem('ci_focus_mode', String(isFocusMode));
  }, [isFocusMode]);

  // keyboard: F to focus, Esc to exit
  useEffect(() => {
    const onKey = (e) => {
      const k = String(e.key || '').toLowerCase();
      if (k === 'f') setIsFocusMode(true);
      if (k === 'escape') setIsFocusMode(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  // ===== n8n Endpoint (configure via env) =====
  const N8N_COMPLIANCE_URL =
    (typeof import.meta !== "undefined" &&
      import.meta.env &&
      import.meta.env.VITE_N8N_COMPLIANCE_URL) ||
    process.env.REACT_APP_N8N_COMPLIANCE_URL ||
    "http://172.16.4.237:8016/webhook/regulatory";

  /* ================= LANGUAGE HELPERS ================= */
  const getTargetLang = (therapyAreaStr) => {
    const m = String(therapyAreaStr || "").match(/·\s*([A-Za-z-]+)/);
    return m?.[1] || "DE";
  };

  /** Normalize incoming segments from router state */
  // Sanju - 01/04/2026 — changed priority: persistedP4 FIRST so returning to this page reads its own saved data
  const segments = useMemo(() => {
    const rawCandidate =
      // Sanju - 01/04/2026 — persistedP4 takes highest priority for bottom-to-top state retention
      (Array.isArray(persistedSegmentsP4) && persistedSegmentsP4.length > 0)
        ? persistedSegmentsP4
        : (Array.isArray(state?.segments) && state.segments.length > 0)
          ? state.segments
          : (Array.isArray(persistedSegmentsP3) && persistedSegmentsP3.length > 0)
            ? persistedSegmentsP3
            : (Array.isArray(persistedSegmentsP2) && persistedSegmentsP2.length > 0)
              ? persistedSegmentsP2
              : (Array.isArray(segmentsProp) && segmentsProp.length > 0)
                ? segmentsProp
                : [];

    return (rawCandidate || [])
      .map((seg, i) => {
        const index = typeof seg.index === "number" ? seg.index : i + 1;
        const source = String(seg.source ?? "");
        const adapted = String(seg.adapted ?? seg.culturallyAdapted ?? seg.translated ?? ""); // phase 3 result if present
        const compliant = String(seg.compliant ?? ""); // phase 4 will fill this
        const words =
          typeof seg.words === "number"
            ? seg.words
            : source.split(/\s+/).filter(Boolean).length;

        return {
          id: seg.id ?? `seg-${index}`,
          index,
          source,
          adapted,   // shown under "Culturally Adapted Text (Phase 3)"
          compliant, // shown under "Regulatory Compliant Text"
          words,
          status: seg.status ?? (adapted.trim() ? "Pending" : "Pending"),
          lang: seg.lang ?? "EN",
          complianceScore: typeof seg.complianceScore === "number" ? seg.complianceScore : null,
          // Sanju - 01/04/2026 — carry forward P4-specific override fields from persisted DB data
          compliantText: seg.compliantText ?? "",
          mlr: seg.mlr ?? null,
          mlrDefer: seg.mlrDefer ?? null,
          acceptedRisk: seg.acceptedRisk ?? null,
          blocked: seg.blocked ?? null,
        };
      })
      .filter((s) => s.source.trim().length > 0)
      .sort((a, b) => a.index - b.index);
  }, [state?.segments, segmentsProp, persistedSegmentsP4, persistedSegmentsP3, persistedSegmentsP2]);

  /** Selected segment */
  const [selectedId, setSelectedId] = useState(null);
  useEffect(() => {
    if (!selectedId && segments.length) setSelectedId(segments[0].id);
  }, [segments, selectedId]);
  const selected = useMemo(
    () => segments.find((s) => s.id === selectedId) || null,
    [segments, selectedId]
  );

  /** Local UI state for score & compliant text (per selection) */
  const [scoreById, setScoreById] = useState({});
  const [compliantById, setCompliantById] = useState({});
  const [hasHydrated, setHasHydrated] = useState(false);

  useEffect(() => {
    // 🆕 If we have already loaded the data, DO NOT run this again! (Stops the freeze)
    //if (!segments || segments.length === 0 || hasHydrated) return;

    if (isLoadingProject || hasHydrated || !segments || segments.length === 0) return;

    const initialScores = {};
    const initialCompliant = {};
    const initialOverrides = {};

    segments.forEach((s) => {
      if (typeof s.complianceScore === "number") initialScores[s.id] = s.complianceScore;
      if (s.compliant?.trim()) initialCompliant[s.id] = s.compliant;
      // Sanju - 01/04/2026 — also hydrate compliantText from persisted P4 segment data
      if (s.status || s.compliantText || s.mlr || s.mlrDefer || s.acceptedRisk || s.blocked) {
        initialOverrides[s.id] = {
          ...(s.status ? { status: s.status } : {}),
          ...(s.compliantText ? { compliantText: s.compliantText } : {}),
          ...(s.mlr ? { mlr: s.mlr } : {}),
          ...(s.mlrDefer ? { mlrDefer: s.mlrDefer } : {}),
          ...(s.acceptedRisk ? { acceptedRisk: s.acceptedRisk } : {}),
          ...(s.blocked ? { blocked: s.blocked } : {}),
        };
      }
    });
    
    // 🆕 Set the state directly
    setScoreById(initialScores);
    setCompliantById(initialCompliant);
    setSegOverrides(initialOverrides);
    
    // 🆕 ENGAGE THE LOCK
    setHasHydrated(true); 
    
  }, [segments, hasHydrated, isLoadingProject]);

  /** Progress (approved count) */
  const progressItems = useMemo(() => {
    const total = segments.length || progressItemsProp.total || 0;
    const approved = segments.filter((s) => (compliantById[s.id] || s.compliant || "").trim().length > 0).length;
    return total > 0 ? { approved, total } : progressItemsProp;
  }, [segments, compliantById, progressItemsProp]);
  /* ================= PER-SEGMENT OVERRIDES ================= */
  const [segOverrides, setSegOverrides] = useState({});
  
  
  const selectedResolved = useMemo(() => {
    if (!selected) return null;
    return { ...selected, ...(segOverrides[selected.id] || {}) };
  }, [selected, segOverrides]);

  const currentSegOverride = segOverrides[selectedResolved?.id] || {};
//sanju - 01_04 — extract decisionType and decisionGroup for the currently selected segment to manage locking and mutual exclusion
  const decisionType  = currentSegOverride.decisionType;
const decisionGroup = currentSegOverride.decisionGroup;

// Lock when ANY decision is taken
const isLocked = Boolean(decisionType);

// Accept-vs-Accept mutual exclusion helper
const isAcceptGroup = decisionGroup === "accept";

  const buildP4Segments = () =>
    segments.map((s) => {
      const o = segOverrides[s.id] || {};
      return {
        ...s,
        complianceScore: scoreById[s.id] ?? s.complianceScore ?? null,
        compliant: compliantById[s.id] ?? s.compliant ?? "",
        status: o.status ?? s.status ?? "Pending",
        ...(o.compliantText ? { compliantText: o.compliantText } : {}),
        ...(o.mlr ? { mlr: o.mlr } : {}),
        ...(o.mlrDefer ? { mlrDefer: o.mlrDefer } : {}),
        ...(o.acceptedRisk ? { acceptedRisk: o.acceptedRisk } : {}),
        ...(o.blocked ? { blocked: o.blocked } : {}),
      };
    });

  // ✅ REAL AUTO-SAVE DEBOUNCE
  useEffect(() => {
    // 🆕 Don't start saving until the page has safely loaded
    if (!projectId || !hasHydrated) return; 

    // 🆕 Wait 1.5 seconds after the user STOPS clicking/typing before saving
    const timeoutId = setTimeout(() => {
      try {
        updateProjectMeta(projectId, { segmentsP4: buildP4Segments() });
      } catch { }
    }, 1500); 

    return () => clearTimeout(timeoutId);
  }, [projectId, segOverrides, scoreById, compliantById, segments, hasHydrated]);

  /* ================= PROGRESS ================= */
  const approvedCount = useMemo(() => {
    return segments.filter((s) => {
      const o = segOverrides[s.id] || {};
      const status = String(o.status ?? s.status ?? "Pending").toLowerCase();
      return status === "approved";
    }).length;
  }, [segments, segOverrides]);

  const flaggedCount = useMemo(() => {
    return segments.filter((s) => {
      const o = segOverrides[s.id] || {};
      const status = String(o.status ?? s.status ?? "Pending").toLowerCase();
      return status === "flagged";
    }).length;
  }, [segments, segOverrides]);

  const changedCount = useMemo(() => {
    return segments.filter((s) => {
      const o = segOverrides[s.id] || {};
      return Boolean((o.compliantText || "").trim());
    }).length;
  }, [segments, segOverrides]);

  const totalCount = segments.length;
  
  // 🆕 NEW: Calculate the local percentage just for Phase 4 segments
  const localProgressPct = totalCount > 0 
    ? Math.round((approvedCount / totalCount) * 100) 
    : 0;
  

  /** Sidebar: retain context when moving across phases 31_03_sanju */
  // Sanju - 01/04/2026 — handlePhaseClick now delegates to gotoPhase which persists P4 first
  const handlePhaseClick = (phaseName) => {
    if (phaseName === "Global Context Capture") {
      // Sanju - 01/04/2026 — use gotoPhase wrapper instead of direct navigate to persist P4 data
      gotoPhase('P1');
    }
    if (phaseName === "Smart TM Translation") {
      // Sanju - 01/04/2026 — use gotoPhase wrapper instead of direct navigate to persist P4 data
      gotoPhase('P2');
    }
    if (phaseName === "Cultural Intelligence") {
      // Sanju - 01/04/2026 — use gotoPhase wrapper instead of direct navigate to persist P4 data
      gotoPhase('P3');
    }
  };

  /* ================= MAIN TABS (Top) ================= */
  const [mainTab, setMainTab] = useState("review"); // review | report | intel

  /* ================= REPORT PAGINATION (display-only) ================= */
  const RC_REPORT_PAGE_SIZE = 10;
  const [rcReportPage, setRcReportPage] = useState(1);
  const [rcReportShowAll, setRcReportShowAll] = useState(false);

  /* ================= ANALYSIS MODAL (n8n renders-only under Critical Issues & Recommendations) ================= */
  const [isAnalysisModalOpen, setIsAnalysisModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("issues"); // issues | pre | templates
  const [isReAnalyzing, setIsReAnalyzing] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const [analysisData, setAnalysisData] = useState({
    score: 70,
    risk: "MEDIUM",
    criticalIssues: [], // keep empty (we only show n8n)
    recommendations: [], // keep empty (we only show n8n)
  });

  // n8n results rendered under Critical Issues & Recommendations
  const [n8nCritical, setN8nCritical] = useState([]); // [{id, text}]
  const [n8nRecs, setN8nRecs] = useState([]); // [{id, text}]
  const [n8nLoading, setN8nLoading] = useState(false);
  const [n8nError, setN8nError] = useState("");

  // Utility: normalize an array of strings into [{id, text}]
  const normalizeStringArray = (arr = [], prefix = "item") =>
    Array.isArray(arr)
      ? arr.map((t, i) => ({ id: `${prefix}-${i + 1}`, text: String(t) }))
      : [];

  // Minimal HTML entity decoding for webhook payloads
  const decodeHtmlEntities = (s = "") =>
    String(s || "")
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'");

  // Split enumerated text like: "1. Item one. 2. Item two. 3. Item three."
  const splitEnumeratedText = (text) => {
    const t = decodeHtmlEntities(String(text || "")).trim();
    if (!t) return [];

    // Insert a delimiter before each "N. " sequence (start or after whitespace/punct)
    const withDelims = t.replace(/(^|[\s;])(\d+)\.\s+/g, "||SEP||");
    const parts = withDelims
      .split("||SEP||")
      .map((p) => p.trim().replace(/^[.;-]+\s*/, ""))
      .filter(Boolean);

    if (parts.length <= 1) {
      const fallback = t
        .split(/\n+|•\s+/g)
        .map((p) => p.trim())
        .filter(Boolean);
      return fallback.length > 1 ? fallback : parts;
    }

    return parts;
  };

  /* ===================== NEW: score & risk helpers ===================== */
  const normalizeScore = (v) => {
    if (v == null) return null;
    if (typeof v === "number" && Number.isFinite(v)) {
      return Math.max(0, Math.min(100, Math.round(v)));
    }
    if (typeof v === "string") {
      // Accept "82", "82%", "82/100", "Score: 82"
      const mPct = v.match(/(\d{1,3})\s*%/);
      const mSlash = v.match(/(\d{1,3})\s*\/\s*100/);
      const mNum = v.match(/(\d{1,3})/);
      let n = null;
      if (mPct) n = parseInt(mPct[1], 10);
      else if (mSlash) n = parseInt(mSlash[1], 10);
      else if (mNum) n = parseInt(mNum[1], 10);
      if (Number.isFinite(n)) {
        return Math.max(0, Math.min(100, n));
      }
    }
    return null;
  };

  const computeRiskFromScore = (score) => {
    if (!Number.isFinite(score)) return "MEDIUM";
    if (score >= 75) return "LOW";
    if (score >= 50) return "MEDIUM";
    return "HIGH";
  };

  // ===== Parser for the provided n8n output shape (+ score & risk support) =====
  // Expected: [ { output: { critical_issue, recommendation1, recommendation2, (optional) score/compliance_score, (optional) risk } } ]
  const parseN8nShape_CritAndRecs = (payload) => {
    try {
      let score = null;
      let risk = null;

      if (!Array.isArray(payload)) return { crit: [], recs: [], score, risk };

      const first = payload[0];
      const out = first?.output ?? first?.Output ?? null;

      if (out && typeof out === "object") {
        const critical_issue = decodeHtmlEntities(String(out.critical_issue || "").trim());
        const recommendation1 = decodeHtmlEntities(String(out.recommendation1 || "").trim());
        const recommendation2 = decodeHtmlEntities(String(out.recommendation2 || "").trim());

        // NEW: optional score / risk fields
        const rawScore = out.score ?? out.compliance_score ?? out.overall_score ?? null;
        score = normalizeScore(rawScore);

        const rawRisk = (out.risk ?? out.risk_level ?? "").toString().trim();
        if (rawRisk) {
          risk = rawRisk.toUpperCase();
        }

        const crit = critical_issue
          ? [{ id: "n8n-crit-1", text: critical_issue }]
          : [];

        const recs = []
          .concat(recommendation1 ? [{ id: "n8n-rec-1", text: recommendation1 }] : [])
          .concat(recommendation2 ? [{ id: "n8n-rec-2", text: recommendation2 }] : []);

        return { crit, recs, score, risk };
      }

      // Fallback: if shape is different, try to split strings
      if (typeof first?.output === "string") {
        const parts = splitEnumeratedText(first.output);
        const crit = parts[0] ? [{ id: "n8n-crit-1", text: parts[0] }] : [];
        const recs = []
          .concat(parts[1] ? [{ id: "n8n-rec-1", text: parts[1] }] : [])
          .concat(parts[2] ? [{ id: "n8n-rec-2", text: parts[2] }] : []);
        // No score/risk in this shape
        return { crit, recs, score: null, risk: null };
      }

      return { crit: [], recs: [], score: null, risk: null };
    } catch {
      return { crit: [], recs: [], score: null, risk: null };
    }
  };

  // (Legacy parser retained for safety if workflows change to earlier string shapes)
  const extractN8nCriticalFromCustomShape = (payload) => {
    try {
      if (Array.isArray(payload) && typeof payload[0]?.output === "string") {
        const out = payload[0].output;

        // Try JSON-in-a-string first (in case)
        try {
          const parsed = JSON.parse(out);
          if (Array.isArray(parsed) && parsed.every((x) => typeof x === "string")) {
            return normalizeStringArray(parsed, "n8n-crit");
          }
          if (
            parsed &&
            typeof parsed === "object" &&
            Array.isArray(parsed.US_Pharma_Regulatory_Rules)
          ) {
            return normalizeStringArray(parsed.US_Pharma_Regulatory_Rules, "n8n-crit");
          }
        } catch {
          // Not JSON; fall through to enumerated split
        }

        const items = splitEnumeratedText(out);
        return normalizeStringArray(items, "n8n-crit");
      }

      // Fallbacks
      if (payload && typeof payload === "object") {
        const maybeArr =
          payload.criticalIssues ||
          payload.issues ||
          (Array.isArray(payload) ? payload : []);
        if (Array.isArray(maybeArr) && maybeArr.every((x) => typeof x === "string")) {
          return normalizeStringArray(maybeArr, "n8n-crit");
        }
      }

      if (Array.isArray(payload) && payload.every((x) => typeof x === "string")) {
        return normalizeStringArray(payload, "n8n-crit");
      }

      return [];
    } catch {
      return [];
    }
  };

  const openAnalysisModal = async () => {
    if (!selectedResolved?.adapted?.trim()) return;

    // Ensure local lists are EMPTY (we only show n8n content)
   setAnalysisData({
  score: null, // Makes the score empty
  risk: "",   // Makes the risk empty
  criticalIssues: [],
  recommendations: [],
});

    // Open modal immediately
    setActiveTab("issues");
    setIsAnalysisModalOpen(true);

    // Begin async n8n call – results will render under Critical Issues and Recommended Changes
    setN8nCritical([]);
    setN8nRecs([]);
    setN8nError("");
    setN8nLoading(true);
    setIsAnalyzing(true);

    const payload = {
      projectName,
      therapyArea,
      segmentId: selectedResolved.id,
      index: selectedResolved.index,
      adaptedText: selectedResolved.adapted,
      country
    };
    console.log('Posting to n8n:', {
      projectName,
      therapyArea,
      segmentId: selectedResolved?.id,
      index: selectedResolved?.index,
      adaptedText: selectedResolved?.adapted,
      country,
    });

    try {
      // ── Azure OpenAI call (replaces n8n /regulatory webhook) ──────────────
      // Posts the same conceptual payload to Azure with the regulatory prompt.
      // Response is wrapped as `[{ output: { critical_issue, recommendation1,
      // recommendation2 } }]` so the existing parseN8nShape_CritAndRecs parser
      // works unchanged.
      const azureEndpoint = (process.env.REACT_APP_AZURE_OPENAI_ENDPOINT || "").replace(/\/+$/, "");
      const azureDeployment = process.env.REACT_APP_AZURE_OPENAI_DEPLOYMENT;
      const azureApiVersion = process.env.REACT_APP_AZURE_OPENAI_API_VERSION || "2024-10-21";
      const azureUrl = `${azureEndpoint}/openai/deployments/${azureDeployment}/chat/completions?api-version=${azureApiVersion}`;

      const azureRes = await fetch(azureUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "api-key": process.env.REACT_APP_AZURE_OPENAI_API_KEY,
        },
        body: JSON.stringify({
          max_completion_tokens: 4096,
          response_format: { type: "json_object" },
          messages: [{ role: "user", content: buildRegulatoryCompliancePrompt(payload) }],
        }),
      });

      if (!azureRes.ok) {
        let errBody = "";
        try { errBody = await azureRes.text(); } catch (_) {}
        console.error("[Azure regulatory non-OK]", azureRes.status, errBody);
        throw new Error(`Regulatory analysis failed (HTTP ${azureRes.status})`);
      }

      const azureData = await azureRes.json();
      const choice = azureData.choices?.[0];
      const finishReason = choice?.finish_reason;
      const rawText = choice?.message?.content;

      if (finishReason === "content_filter") {
        console.error("[Azure content filter on regulatory]", choice?.content_filter_results);
        throw new Error("Azure content filter blocked the regulatory analysis. Check console.");
      }
      if (!rawText || typeof rawText !== "string" || rawText.trim() === "") {
        throw new Error(`Regulatory analysis returned empty content (finish_reason=${finishReason ?? "unknown"})`);
      }

      let parsedRegulatory;
      try {
        parsedRegulatory = JSON.parse(rawText.trim());
      } catch (e) {
        const match = rawText.match(/\{[\s\S]*\}/);
        if (match) {
          parsedRegulatory = JSON.parse(match[0]);
        } else {
          console.error("[Regulatory: no JSON found]", rawText);
          throw new Error("Regulatory analysis response was not valid JSON");
        }
      }

      // Wrap in the n8n response shape so parseN8nShape_CritAndRecs handles it
      const raw = [{ output: parsedRegulatory }];

      // Prefer the specific shape (critical_issue, recommendation1, recommendation2, score?, risk?)
      const { crit, recs, score, risk } = parseN8nShape_CritAndRecs(raw);

      // ===== NEW: apply score & risk from n8n if present =====
      if (Number.isFinite(score)) {
        // Update modal "Overall Compliance Score"
        setAnalysisData((prev) => ({
          ...prev,
          score,
          risk: risk || computeRiskFromScore(score),
        }));

        // Also persist per-segment score (updates the badge in the Adapted card)
        setScoreById((prev) => ({ ...prev, [selectedResolved.id]: score }));
      } else {
        // If no score provided but risk provided, still update risk
        if (risk) {
          setAnalysisData((prev) => ({ ...prev, risk }));
        }
      }

      // Critical
      if ((crit || []).length === 0) {
        // Fallback to legacy extraction if no crit found
        const legacyCrit = extractN8nCriticalFromCustomShape(raw);
        if (legacyCrit.length > 0) {
          setN8nCritical(legacyCrit);
        } else {
          setN8nError("No critical issue returned by AI for this segment.");
        }
      } else {
        setN8nCritical(crit);
      }

      // Recommendations (ONLY from n8n)
      setN8nRecs(recs || []);
    } catch (err) {
      setN8nError(err?.message || "Failed to analyze with AI.");
    } finally {
      setN8nLoading(false);
      setIsAnalyzing(false);
    }
  };

  const [isReAnalyzeDisabled] = useState(false);

  const compliantEditorValue = selectedResolved?.compliantText ?? "";
  const setCompliantEditorValue = (val) => {
    if (!selectedResolved) return;
    setSegOverrides((prev) => ({
      ...prev,
      [selectedResolved.id]: {
        ...prev[selectedResolved.id],
        compliantText: val,
      },
    }));
  };

  const handleApprove = () => {
    if (!selectedResolved) return;
    setSegOverrides((prev) => ({
      ...prev,
      [selectedResolved.id]: {
        ...prev[selectedResolved.id],
        status: "Approved",
      },
    }));
  };

  const handleFlag = () => {
    if (!selectedResolved) return;
    setSegOverrides((prev) => ({
      ...prev,
      [selectedResolved.id]: {
        ...prev[selectedResolved.id],
        status: "Flagged",
      },
    }));
  };

  //sanju_01_04
  const textAlreadyApplied = (existingText = "", newText = "") => {
  return existingText.includes(newText);
};

  /* ============ Analysis actions ============ sanju_01_04 */
  const applyCompliantSuggestion = (recText) => {
  if (!selectedResolved) return;

  const existing = selectedResolved.compliantText || "";

  // ✅ PREVENT DUPLICATE
  if (textAlreadyApplied(existing, recText)) return;

  const updated =
    existing.trim().length > 0
      ? existing + "\n\n• " + recText
      : "• " + recText;

  setSegOverrides((prev) => ({
    ...prev,
    [selectedResolved.id]: {
      ...prev[selectedResolved.id],
      compliantText: updated,
      decisionType: "apply_change",
      decisionGroup: "accept",
    },
  }));
};

  const acceptRecommendation = (recText) => {
  if (!selectedResolved) return;

  const existing = selectedResolved.compliantText || "";

  // ✅ PREVENT DUPLICATE
  if (textAlreadyApplied(existing, recText)) return;

  const updated =
    existing.trim().length > 0
      ? existing + "\n\n• " + recText
      : "• " + recText;

  setSegOverrides((prev) => ({
    ...prev,
    [selectedResolved.id]: {
      ...prev[selectedResolved.id],
      compliantText: updated,
      decisionType: "accept_reco",
      decisionGroup: "accept",
    },
  }));
};

  const reAnalyzeInModal = async () => {
    setIsReAnalyzing(true);
    setTimeout(() => setIsReAnalyzing(false), 800);
  };

  const markCompliantFromModal = () => {
    handleApprove();
    setIsAnalysisModalOpen(false);
  };

  //Hari
  // const handleCompleteCompliance = async () => {
  //   if (!projectId) return;
  //   try {
  //     // 1. Mark Phase 4 (Regulatory) as complete in the DB
  //     //Hari
  //     await markPhaseComplete(projectId, 'P4');
     
  //     // 2. Trigger the local event to refresh the progress bar immediately
  //     window.dispatchEvent(new Event('glocal_progress_updated'));
     
  //     console.log("Compliance phase marked as complete.");
  //   } catch (err) {
  //     console.error("Failed to complete phase:", err);
  //   }
  // };

  //Kathir-25/3
    const handleCompleteCompliance = async () => {
    if (!projectId) return;
    try {
      // Sanju - 01/04/2026 — persist P4 segments before marking phase complete
      await updateProjectMeta(projectId, { segmentsP4: buildP4Segments() });

      // 1. Mark Phase 4 (Regulatory) as complete in the DB
      await markPhaseComplete(projectId, 'P4');
     
      // ✅ FIX: Micro-delay to ensure the Sidebar and Progress Ring
      // receive the "100%" update event before the function finishes.
      await new Promise(resolve => setTimeout(resolve, 50));
     
      // 2. Trigger the local event to refresh the progress bar immediately
      window.dispatchEvent(new Event('glocal_progress_updated'));
     
      console.log("Compliance phase marked as complete. Progress should now be 100%.");
    } catch (err) {
      console.error("Failed to complete phase:", err);
    }
  };
 

  /* ================= Request MLR Exception ================= */
  const [isMlrOpen, setIsMlrOpen] = useState(false);
  const [mlrRuleText, setMlrRuleText] = useState("");
  const [mlrReason, setMlrReason] = useState("");
  const [mlrTouched, setMlrTouched] = useState(false);
  const [mlrSubmitting, setMlrSubmitting] = useState(false);

  const openMlrModal = (ruleText) => {
    setMlrRuleText(ruleText || "");
    setMlrReason("");
    setMlrTouched(false);
    setIsMlrOpen(true);
  };

  const submitMlr = async () => {
    setMlrTouched(true);
    if (!mlrReason.trim()) return;
    setMlrSubmitting(true);

    const payload = {
      rule: mlrRuleText,
      reasoning: mlrReason.trim(),
      at: new Date().toISOString(),
    };

    setSegOverrides((prev) => ({
      ...prev,
      [selectedResolved.id]: {
        ...prev[selectedResolved.id],
        status: "Flagged",
        mlr: payload,
        decisionType: "mlr", //sanju_01_04
        decisionGroup: "other", //sanju_01_04
      },
    }));

    setTimeout(() => {
      setMlrSubmitting(false);
      setIsMlrOpen(false);
    }, 300);
  };

  /* ================= Defer to MLR Review ================= */
  const [isDeferOpen, setIsDeferOpen] = useState(false);
  const [deferRuleText, setDeferRuleText] = useState("");
  const [deferReason, setDeferReason] = useState("");
  const [deferTouched, setDeferTouched] = useState(false);
  const [deferSubmitting, setDeferSubmitting] = useState(false);

  const openDeferModal = (ruleText) => {
    setDeferRuleText(ruleText || "");
    setDeferReason("");
    setDeferTouched(false);
    setIsDeferOpen(true);
  };

  const submitDefer = async () => {
    setDeferTouched(true);
    if (!deferReason.trim()) return;
    setDeferSubmitting(true);

    const payload = {
      rule: deferRuleText,
      reasoning: deferReason.trim(),
      at: new Date().toISOString(),
    };

    setSegOverrides((prev) => ({
      ...prev,
      [selectedResolved.id]: {
        ...prev[selectedResolved.id],
        status: "Flagged",
        mlrDefer: payload,
        
decisionType: "defer",      // sanju_01_04
    decisionGroup: "other",  //sanju_01_04

      },
    }));

    setTimeout(() => {
      setDeferSubmitting(false);
      setIsDeferOpen(false);
    }, 300);
  };

  /* ================= Accept Risk & Skip ================= */
  const [isRiskOpen, setIsRiskOpen] = useState(false);
  const [riskRuleText, setRiskRuleText] = useState("");
  const [riskReason, setRiskReason] = useState("");
  const [riskTouched, setRiskTouched] = useState(false);
  const [riskSubmitting, setRiskSubmitting] = useState(false);

  const openRiskModal = (ruleText) => {
    setRiskRuleText(ruleText || "");
    setRiskReason("");
    setRiskTouched(false);
    setIsRiskOpen(true);
  };

  const submitRisk = async () => {
    setRiskTouched(true);
    if (!riskReason.trim()) return;
    setRiskSubmitting(true);

    const payload = {
      rule: riskRuleText,
      reasoning: riskReason.trim(),
      at: new Date().toISOString(),
    };

    setSegOverrides((prev) => ({
      ...prev,
      [selectedResolved.id]: {
        ...prev[selectedResolved.id],
        acceptedRisk: payload,
        
       decisionType: "risk",       // sanju_01_04
       decisionGroup: "other", //sanju_01_04

      },
    }));

    setTimeout(() => {
      setRiskSubmitting(false);
      setIsRiskOpen(false);
    }, 300);
  };

  /* ================= Mark as Blocking ================= */
  const [isBlockOpen, setIsBlockOpen] = useState(false);
  const [blockRuleText, setBlockRuleText] = useState("");
  const [blockReason, setBlockReason] = useState(
    "Marked as blocking - must be resolved before approval"
  );
  const [blockTouched, setBlockTouched] = useState(false);
  const [blockSubmitting, setBlockSubmitting] = useState(false);

  const openBlockModal = (ruleText) => {
    setBlockRuleText(ruleText || "");
    setBlockReason("Marked as blocking - must be resolved before approval");
    setBlockTouched(false);
    setIsBlockOpen(true);
  };

  const submitBlock = async () => {
    setBlockTouched(true);
    if (!blockReason.trim()) return;
    setBlockSubmitting(true);

    const payload = {
      rule: blockRuleText,
      reasoning: blockReason.trim(),
      at: new Date().toISOString(),
    };

    setSegOverrides((prev) => ({
      ...prev,
      [selectedResolved.id]: {
        ...prev[selectedResolved.id],
        status: "Flagged",
        blocked: payload,
       decisionType: "block",      // sanju_01_04
       decisionGroup: "other", //sanju_01_04

      },
    }));

    setTimeout(() => {
      setBlockSubmitting(false);
      setIsBlockOpen(false);
      setIsAnalysisModalOpen(false);
    }, 300);
  };

  /* ================= Navigation ================= */
  const goBack = () => navigate(-1);

  /* ================= Derived: Report / Intel ================= */
  const avgCompliance = totalCount ? Math.round((approvedCount / totalCount) * 100) : 0;
  const criticalIssuesCount = 0; // left as-is (report widgets unchanged)
  const totalChanges = changedCount;
const overallComplianceScoreFromModal = analysisData?.score ?? null; // number | null

  /* ================= Export Report (simple .txt) ================= */
  const exportReport = () => {
    const lines = [
      `Project: ${projectName}`,
      `Therapy Area: ${therapyArea}`,
      `Generated: ${new Date().toLocaleString()}`,
      "",
      "Final Regulatory-Compliant Translation",
      "======================================",
      "",
      ...segments.map((seg) => {
        const adapted = (seg.adapted || "").trim() ? seg.adapted : "— No adapted text —";
        return `Segment ${seg.index}\n${adapted}\n`;
      }),
    ];
    const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${projectName.replace(/\s+/g, "_")}_Compliance_Report.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  /** Heuristic score (still available for manual Run Compliance Check button) */
  const heuristicScore = (text) => {
    const t = String(text || "");
    const base = Math.min(100, Math.round(t.length / 3));
    const hasBrand = /ofev|nintedanib/i.test(t);
    const hasRisk = /risk|warning|contraindication/i.test(t);
    return Math.max(0, Math.min(100, base + (hasBrand ? 10 : 0) + (hasRisk ? 8 : 0)));
  };

  /** Actions on detail panel */
  const runComplianceCheck = () => {
    if (!selected) return;
    const score = heuristicScore(selected.adapted);
    setScoreById((prev) => ({ ...prev, [selected.id]: score }));
  };

  const flagForReview = () => {
    if (!selected) return;
    alert(`Segment ${selected.index} flagged for regulatory review.`);
  };

  const approveCompliant = () => {
    if (!selected) return;
    const text = selected.adapted?.trim().length ? selected.adapted : selected.source;
    setCompliantById((prev) => ({ ...prev, [selected.id]: text }));
  };

  /** Complete Phase → next page */
  const handleCompletePhase = () => {
    navigate("/qualityIntelligence", {
      state: {
        projectName,
        segments: segments.map((s) => ({
          ...s,
          complianceScore: scoreById[s.id] ?? s.complianceScore ?? null,
          compliant: compliantById[s.id] ?? s.compliant ?? "",
        })),
      },
    });
  };

  return (
    <div className={`regulatory tm-app ${isFocusMode ? 'is-focus' : ''}`}>
      {/* Sidebar */}
         <aside className="tm-sidebar" aria-label="Workflow Phases">
          {/* ✅ ADDED: Opacity fade when loading */}
          {/* Hari-24/3 */}
  <div className="tm-sidebar-progress" style={{ opacity: isProgressLoading ? 0.6 : 1, transition: 'opacity 0.3s' }}>
    <div className="tm-progress-row">
      <span className="tm-progress-label">Overall Progress</span>
      {/* ✅ FIXED: Show "..." while loading instead of 0% */}
      <span className="tm-progress-value">
        {isProgressLoading ? "..." : `${overallPercent}%`}
      </span>
    </div>
    <div className="tm-progress-sub">
      {/* ✅ FIXED: Show "Syncing..." instead of 0 / 4 */}
      {isProgressLoading ? "Loading..." : `${completedCount} / ${totalTargetPhases} phases completed`}
    </div>
    <div
      className="tm-progress-bar"
      role="progressbar"
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={overallPercent}
    >
      <div
        className="tm-progress-fill"
        style={{ width: `${overallPercent}%`, transition: 'width 0.4s ease-in-out' }}
      />
    </div>
  </div>
 
  <nav className="tm-phases">
    {SIDEBAR_PHASES.map((p) => {
      // isDone is true if the phase ID (P1, P2, etc) exists in the database/progressStore
      const isDone = completedSet.has(p.id.toUpperCase());
      const isActive = p.name === "Regulatory Compliance";
 
      return (
        <button
          key={p.id}
          className={`tm-phase-item ${isDone ? "done" : p.status} ${
            isActive ? "is-active" : ""
          }`}
          aria-label={`Open ${p.name}`}
          onClick={() => gotoPhase(p.id)}
        >
          {/* <span className={`tm-phase-icon ${p.iconClass}`} /> */}
          <span className={`tm-phase-icon ${p.color || ''}`}>{p.icon}</span>
          <span className="tm-phase-text">
            <span className="tm-phase-title">{p.name}</span>
            <span className="tm-phase-sub">{p.sub}</span>
          </span>
          {/* Checkmark appears only if the database confirms phase is complete */}
          {/* {isDone && (
            <span className="tm-phase-check" aria-hidden={true}>
              ✓
            </span>
          )} */}

          {/* Checkmark appears only if the database confirms phase is complete */}
          {isDone && !isProgressLoading && (
            <span className="tm-phase-check" aria-hidden={true}>
              ✓
            </span>
          )}
          {isActive && !isDone && !isProgressLoading && (
            <span className="tm-phase-dot" aria-hidden={true} />
          )}
          {/* {isActive && !isDone && (
            <span className="tm-phase-dot" aria-hidden={true} />
          )} */}
        </button>
      );
    })}
  </nav>
</aside>

      {/* Main */}
      <div className="tm-main">
        {/* Header */}
        <header className="tm-header">
          <div className="tm-header-left">
            <div className="tm-crumbs">
              <button className="tm-crumb" onClick={() => navigate('/')}>
                <ArrowLeft size={14} className="h-1 w-1 mr-2" /> Main Hub
              </button>
              <span className="tm-divider" />
              <button className="tm-crumb" onClick={() => navigate('/glocalizationHub')}>
                Glocalization Hub
              </button>
            </div>

            <div className="tm-header-center">
              <div className="tm-title-row">
                <h1 className="tm-page-title">{projectName}</h1>
              </div>
            </div>
          </div>

          <div className="tm-header-right">
            <span className="tm-saved">
              <CheckCircle2 size={12} className="h-1 w-1 text-green-600" />
              Saved
            </span>

            <button className="tm-btn ghost tm-btn-icon">
              <Save size={15} className="h-4 w-4 mr-2" /> Save
            </button>

            <button
              className="tm-btn ghost tm-btn-icon"
              onClick={toggleFocusMode}
              aria-pressed={isFocusMode}
              title={isFocusMode ? 'Exit focus (Esc)' : 'Enter focus (F)'}
            >
              {isFocusMode ? (
                <>
                  <Minimize2 size={16} /> Exit
                </>
              ) : (
                <>
                  <Maximize2 size={16} /> Focus
                </>
              )}
            </button>
          </div>
        </header>

        {/* Tabs bar */}
        <section className="tm-tabs-bar">
          <div className="tm-tabs">
            <button
              className={`tm-tab ${mainTab === "review" ? "is-active" : ""}`}
              onClick={() => setMainTab("review")}
            >
              Compliance Review
            </button>
            <button
              className={`tm-tab ${mainTab === "report" ? "is-active" : ""}`}
              onClick={() => setMainTab("report")}
            >
              Compliance Report
            </button>
            <button
              className={`tm-tab ${mainTab === "intel" ? "is-active" : ""}`}
              onClick={() => setMainTab("intel")}
            >
              Regulatory Intelligence
            </button>
          </div>
        </section>

        {mainTab === "review" && (
          <div>
            {/*sanju_01_04 */}
            <section className="tm-tabs-right" style={{ display: 'flex', alignItems: 'center', gap: '5px' }}> 
  <div className="tm-status-left">
    <h2 className="tm-section-title">
      <Shield size={20} className="h-5 w-5" />
      Regulatory Compliance Workspace
    </h2>
    <p className="tm-section-sub">
      Review culturally adapted content for regulatory compliance and market requirements
    </p>
  </div>
 
  <div className="tm-actions-row" style={{ display: 'flex', alignItems: 'center', gap: '16px', marginLeft: 'auto' }}>
    {/* 🆕 COMPLETE BUTTON: Positioned left of progress */}
    {/* <button
      className="tm-btn tm-btn-primary"
      onClick={handleCompleteCompliance}
      style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 16px' }}
    >
      <CheckCircle size={18} />
      Complete Phase
    </button>
  */}
    <div className="tm-progress-inline">
      <span className="tm-progress-inline-label">Progress:</span>
      {/* <span className="tm-progress-inline-value">
        {completedCount === 4 ? "100%" : "75%"}
      </span> */}
      <span className="tm-progress-inline-value">
                    {approvedCount} / {totalCount} approved
                  </span>
      <div className="tm-progress-inline-bar">
        {/* Uses the overallPercent we set up in the previous step */}
        <div
          className="tm-progress-inline-fill"
          style={{ width: `${localProgressPct}%`, transition: 'width 0.5s ease-in-out' }}
        />
      </div>
    </div>
    {/*sanju_01_04 */}
     <button
      className="tm-btn-primary"
      onClick={handleCompleteCompliance}
      //style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 16px' }}
    >
      <CheckCircle size={14} />
      Complete Phase
    </button>
 
  </div>
</section>

            {/* 🆕 NEW: LOADING GATE STARTS HERE */}
            {isLoadingProject ? (
              <div className="tm-workspace-loading" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '6rem 0', color: '#6B7280' }}>
                <Loader2 size={32} className="animate-spin mb-4 text-emerald-600" />
                <p>Syncing Data...</p>
              </div>
            ) : (
              
            <section className="tm-workspace rc-workspace">
              {/* Workspace grid */}

              <div className="tm-card tm-left">
                <div className="tm-card-header">
                  <h3 className="tm-card-title">Content Segments</h3>
                  <span className="tm-light">{segments.length} segments to review</span>
                </div>

                <div className="tm-seg-list" style={{ maxHeight: "calc(100vh - 280px)", overflowY: "auto" }}>
                  {segments.map((seg) => {
                    const isSelected = seg.id === selectedId;
                    return (
                      <button
                        key={seg.id}
                        className={`tm-seg-item ${isSelected ? "is-selected" : ""}`}
                        onClick={() => setSelectedId(seg.id)}
                        aria-label={`Open Segment ${seg.index}`}
                      >
                        <div className="tm-seg-item-top">
                          <span className="tm-ci-index">Segment {seg.index}</span>
                          <span className="tm-seg-state">
                            {(() => {
                              const o = segOverrides[seg.id] || {};
                              const st = String(o.status ?? seg.status ?? "Pending").toLowerCase();
                              return (
                                <span className="tm-seg-state">
                                  {st === "approved" ? "Approved" : st === "flagged" ? "Flagged" : "Pending"}
                                </span>
                              );
                            })()}
                          </span>
                        </div>
                        <div className="tm-seg-snippet">{seg.source}</div>
                        <div className="tm-seg-meta-row">
                          <span className="tm-seg-meta">{seg.words} words</span>
                        </div>
                      </button>
                    );
                  })}
                  {segments.length === 0 && (
                    <div className="tm-empty">No segment present to display.</div>
                  )}
                </div>
              </div>

              <div className="tm-card tm-right">
                {selected && (
                  <div className="tm-detail">

                    {/* ===== 1) Source Text ===== */}
                    <div className="rc-section">
                      <div className="rc-section-head">
                        <span className="rc-chip blue">Source Text</span>
                      </div>

                      <div className="rc-source-body">
                        {selectedResolved.source}
                      </div>
                    </div>

                    {/* ===== 2) Culturally Adapted Text (Phase 3) ===== */}
                    <div className="rc-section">
                      <div className="rc-section-head">
                        <span className="rc-chip blue">Culturally Adapted Text (Phase 3)</span>

                        <div className="rc-tools-inline">
                          <span className="rc-score-pill">
                            Score: {typeof scoreById[selected.id] === "number" ? `${scoreById[selected.id]}/100` : "—"}
                          </span>
                          <button
                            className="rc-btn-check"
                            onClick={openAnalysisModal}
                            disabled={!selectedResolved.adapted?.trim() || isAnalyzing}
                            title={
                              selectedResolved.adapted?.trim()
                                ? "Open Compliance Analysis"
                                : "No adapted text to check"
                            }
                          >
                            <Shield size={15} className="h-5 w-5" />
                            {isAnalyzing ? "Analyzing…" : "Run Compliance Check"}
                          </button>
                        </div>
                      </div>

                      <div className="rc-adapted-card">
                        <div className="rc-adapted-body">
                          {selectedResolved.adapted?.trim()
                            ? selectedResolved.adapted
                            : <span className="rc-muted">— No adapted text —</span>}
                        </div>
                      </div>
                    </div>

                    {/* ===== 3) Regulatory Compliant Text ===== */}
                    <div className="rc-section">
                      <div className="rc-section-head">
                        <span className="rc-chip green">Regulatory Compliant Text</span>

                        <div className="rc-tools-inline">
                          <button className="rc-link-flag" onClick={handleFlag}>
                            <Flag size={12} className="h-4 w-4 mr-2" />
                            Flag for Review
                          </button>
                          <button className="rc-btn-approve" onClick={handleApprove}>
                            <CheckCircle size={12} className="h-4 w-4 mr-2" />
                            Approve
                          </button>
                        </div>
                      </div>

                      <textarea
                        // className="rc-textarea"
                        // placeholder="Enter or edit the final compliant text here…"
                        // value={compliantEditorValue}
                        // onChange={(e) => setCompliantEditorValue(e.target.value)}
                        
                        className="rc-textarea"
  placeholder="Awaiting Regulatory Compliance text"
  value={compliantEditorValue}
  readOnly // This prevents the user from typing or deleting text
                      />
                    </div>

                  </div>
                )}
              </div>
            </section>
          
        
        )}
        </div>
        )}

        {mainTab === "report" && (
          <div className="rc-report">
            {/* SUMMARY CARDS */}
            <div className="rc-report-cards">
              <div className="rc-report-card">
                <div className="rc-report-card-label">Segments Approved</div>
                <div className="rc-report-card-value">
                  {approvedCount}/{totalCount}
                </div>
              </div>
              <div className="rc-report-card">
                <div className="rc-report-card-label">Critical Issues</div>
                <div className="rc-report-card-value danger">{criticalIssuesCount}</div>
              </div>
              <div className="rc-report-card">
                <div className="rc-report-card-label">Avg Compliance Score</div>
                    <div className="rc-report-card-value"> {overallComplianceScoreFromModal != null ? `${overallComplianceScoreFromModal}%` : "—"}</div>
              </div>
              <div className="rc-report-card">
                <div className="rc-report-card-label">Total Changes</div>
                <div className="rc-report-card-value">{totalChanges}</div>
              </div>
            </div>

            {/* FINAL REGULATORY-COMPLIANT TRANSLATION */}
            <div className="rc-card rc-report-list">
              <div className="rc-card-head">
                <div className="rc-card-title">Final Regulatory-Compliant Translation</div>
                <div className="rc-card-actions">
                  <button className="rc-btn outline" onClick={exportReport}>
                    Export Report
                  </button>
                </div>
              </div>

              {segments.length === 0 ? (
                <div className="rc-report-items">
                  <div className="rc-empty">No segments found.</div>
                </div>
              ) : (() => {
                const rcTotalPages = Math.max(1, Math.ceil(segments.length / RC_REPORT_PAGE_SIZE));
                const rcSafePage = Math.min(rcReportPage, rcTotalPages);
                const firstIdx = (rcSafePage - 1) * RC_REPORT_PAGE_SIZE + 1;
                const lastIdx = Math.min(rcSafePage * RC_REPORT_PAGE_SIZE, segments.length);
                const visible = rcReportShowAll
                  ? segments
                  : segments.slice((rcSafePage - 1) * RC_REPORT_PAGE_SIZE, rcSafePage * RC_REPORT_PAGE_SIZE);
                const goPrev = () => setRcReportPage((p) => Math.max(1, p - 1));
                const goNext = () => setRcReportPage((p) => Math.min(rcTotalPages, p + 1));
                const toggleShowAll = () => { setRcReportShowAll((v) => !v); setRcReportPage(1); };

                return (
                  <>
                    <div className="d-flex align-items-center justify-content-between flex-wrap" style={{ gap: 8, padding: "10px 14px", borderBottom: "1px solid #eef2f7" }}>
                      <div className="text-muted small">
                        {rcReportShowAll
                          ? `Showing all ${segments.length} segments`
                          : `Showing ${firstIdx}–${lastIdx} of ${segments.length} segments`}
                      </div>
                      <div className="d-flex align-items-center" style={{ gap: 6 }}>
                        {!rcReportShowAll && (
                          <>
                            <button type="button" className="btn btn-sm btn-outline-secondary" onClick={goPrev} disabled={rcSafePage <= 1}>← Prev</button>
                            <span className="small">Page {rcSafePage} of {rcTotalPages}</span>
                            <button type="button" className="btn btn-sm btn-outline-secondary" onClick={goNext} disabled={rcSafePage >= rcTotalPages}>Next →</button>
                          </>
                        )}
                        <button type="button" className="btn btn-sm btn-outline-primary" onClick={toggleShowAll}>
                          {rcReportShowAll ? "Paginate" : "Show all"}
                        </button>
                      </div>
                    </div>

                    <div className="rc-report-items">
                      {visible.map((seg) => {
                        const finalCompliantText =
                          (seg.compliantText && seg.compliantText.trim()) ||
                          (seg.compliant && seg.compliant.trim()) ||
                          "— No regulatory compliant text —";
                        return (
                          <div className="rc-report-item" key={`rep-${seg.id}`}>
                            <div className="rc-report-item-head">
                              <span className="rc-report-item-index">Segment {seg.index}</span>
                            </div>
                            <div className="rc-report-item-body">
                              <pre className="rc-pre">{finalCompliantText}</pre>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {!rcReportShowAll && rcTotalPages > 1 && (
                      <div className="d-flex justify-content-center align-items-center" style={{ gap: 8, padding: "12px 14px", borderTop: "1px solid #eef2f7" }}>
                        <button type="button" className="btn btn-sm btn-outline-secondary" onClick={goPrev} disabled={rcSafePage <= 1}>← Prev</button>
                        <span className="small">Page {rcSafePage} of {rcTotalPages}</span>
                        <button type="button" className="btn btn-sm btn-outline-secondary" onClick={goNext} disabled={rcSafePage >= rcTotalPages}>Next →</button>
                      </div>
                    )}
                  </>
                );
              })()}
            </div>
          </div>
        )}

        {mainTab === "intel" && (
          <div className="rc-intel">
            {/* DASHBOARD HEADER */}
            <div className="rc-intel-head">
              <div className="rc-intel-title">Regulatory Intelligence Dashboard</div>
              <span className="rc-chip small success">Compliance: {avgCompliance}%</span>
            </div>

            {/* KPI CARDS */}
            <div className="rc-intel-kpis">
              <div className="rc-intel-kpi">
                <div className="rc-intel-kpi-top">Overall Compliance</div>
                <div className="rc-intel-kpi-value">{avgCompliance}%</div>
              </div>
              <div className="rc-intel-kpi">
                <div className="rc-intel-kpi-top">Passed Rules</div>
                <div className="rc-intel-kpi-value">{approvedCount}</div>
              </div>
              <div className="rc-intel-kpi">
                <div className="rc-intel-kpi-top">Warnings</div>
                <div className="rc-intel-kpi-value">{flaggedCount}</div>
              </div>
              <div className="rc-intel-kpi">
                <div className="rc-intel-kpi-top">Critical Issues</div>
                <div className="rc-intel-kpi-value danger">{criticalIssuesCount}</div>
              </div>
            </div>

            {/* INNER TABS */}
            <IntelInnerTabs
              locale={getTargetLang(therapyArea)}
              overallPct={avgCompliance}
            />
          </div>
        )}
      </div>

      {/* ================== ANALYSIS POPUP ================== */}
      {isAnalysisModalOpen && selectedResolved && (
        <div
          className="rcm-modal-backdrop"
          role="dialog"
          aria-modal="true"
          aria-label={`Regulatory Compliance Analysis - Segment ${selectedResolved.index}`}
          onClick={(e) => {
            if (e.target === e.currentTarget) setIsAnalysisModalOpen(false);
          }}
        >
          <div className="rcm-modal">
            {/* HEADER */}
            <div className="rcm-modal__header">
              <div className="rcm-modal__title">
                <span className="rcm-bullet" />
                Regulatory Compliance Analysis - Segment {selectedResolved.index}
              </div>
              <div className="rcm-modal__chips">
                <span className={`rcm-chip risk ${analysisData.risk.toLowerCase()}`}>
                  {analysisData.risk[0] + analysisData.risk.slice(1).toLowerCase()} Risk
                </span>
                <span className="rcm-chip score">Score: {analysisData.score}%</span>
              </div>
            </div>

            {/* TABS */}
            <div className="rcm-tabs">
              <button
                className={activeTab === "issues" ? "active" : ""}
                onClick={() => setActiveTab("issues")}
              >
                Compliance Issues{" "}
                <span className="rc-tab-badge">
                  {analysisData.criticalIssues.length + n8nCritical.length + n8nRecs.length}
                </span>
              </button>
              <button
                className={activeTab === "pre" ? "active" : ""}
                onClick={() => setActiveTab("pre")}
              >
                Pre-Approved Content
              </button>
              <button
                className={activeTab === "templates" ? "active" : ""}
                onClick={() => setActiveTab("templates")}
              >
                Regulatory Templates
              </button>
            </div>

            {/* BODY */}
            <div className="rcm-modal__body">
              {/* Overall score row */}
              <div className="rcm-overall">
                <div className="rcm-overall__left">
                  <div className="rcm-overall__label">Overall Compliance Score</div>
                    <div className="rcm-overall__value">   {analysisData.score !== null ? `${analysisData.score}/100` : ""} </div>
                    </div>
                <div className="rcm-overall__right">
                  <div className="rcm-overall__sub">Risk Level</div>
                  <div className={`rcm-overall__risk ${analysisData.risk.toLowerCase()}`}>
                    {analysisData.risk}
                  </div>
                </div>
              </div>

              {/* Critical Issues */}
              <div className="rcm-section-title">
                <span className="rcm-icon warn">!</span>
                Critical Issues – Must Change{" "}
                <span className="rc-tab-badge">
                  {analysisData.criticalIssues.length + n8nCritical.length}
                </span>
              </div>

              {/* Existing (kept empty) critical issues structure */}
              {analysisData.criticalIssues.map((it) => {
                const mlrMatch = currentSegOverride?.mlr?.rule === it.text;
                return (
                  <div key={it.id} className="rcm-issue rcm-issue--critical">
                    <div className="rcm-issue__content">{it.text}</div>

                    {!mlrMatch && (
                      <div className="rcm-issue__actions">
                       <button
  className="btn success"
  disabled={isLocked && decisionType !== "apply_change"}
  onClick={() => applyCompliantSuggestion(it.text)}
>
  ✓ Accept & Apply Changes
</button>
                       
<button
  className="btn outline"
  disabled={isLocked}
  onClick={() => openMlrModal(it.text)}
>
  ⓘ Request MLR Exception
</button>

                       
<button
  className="btn danger"
  disabled={isLocked}
  onClick={() => openBlockModal(it.text)}
>
  ⛔ Mark as Blocking
</button>

                      </div>
                    )}

                    {mlrMatch && (
                      <div className="rcm-logged-note">
                        <div className="rcm-logged-note__label">Decision Reasoning:</div>
                        <textarea
                          className="rcm-logged-note__textarea"
                          value={currentSegOverride.mlr.reasoning}
                          readOnly
                        />
                        <div className="rcm-logged-note__meta">
                          Logged at: {new Date(currentSegOverride.mlr.at).toLocaleString()}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}

              {/* n8n loading indicator */}
              {n8nLoading && (
                <div className="rcm-issue rcm-issue--critical" key="n8n-loading">
                  <div className="rcm-issue__content">Analyzing with AI…</div>
                </div>
              )}

              {/* n8n error (appended, non-blocking) */}
              {!n8nLoading && n8nError && (
                <div className="rcm-issue rcm-issue--critical" key="n8n-error">
                  <div className="rcm-issue__content">{n8nError}</div>
                </div>
              )}

              {/* n8n results under Critical Issues */}
              {!n8nLoading &&
                !n8nError &&
                n8nCritical.map((it) => {
                  const mlrMatch = currentSegOverride?.mlr?.rule === it.text;
                  return (
                    <div key={it.id} className="rcm-issue rcm-issue--critical">
                      <div className="rcm-issue__content">{it.text}</div>

                      {!mlrMatch && (
                        <div className="rcm-issue__actions">
                          <button className="btn success" onClick={() => applyCompliantSuggestion(it.text)}>
                            ✓ Accept &amp; Apply Changes
                          </button>
                          <button className="btn outline" onClick={() => openMlrModal(it.text)}>
                            ⓘ Request MLR Exception
                          </button>
                          <button className="btn danger" onClick={() => openBlockModal(it.text)}>
                            ⛔ Mark as Blocking
                          </button>
                        </div>
                      )}

                      {mlrMatch && (
                        <div className="rcm-logged-note">
                          <div className="rcm-logged-note__label">Decision Reasoning:</div>
                          <textarea
                            className="rcm-logged-note__textarea"
                            value={currentSegOverride.mlr.reasoning}
                            readOnly
                          />
                          <div className="rcm-logged-note__meta">
                            Logged at: {new Date(currentSegOverride.mlr.at).toLocaleString()}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}

              {/* Recommended Changes (ONLY from n8n) */}
              <div className="rcm-section-title">
                <span className="rcm-icon info">○</span>
                Recommended Changes{" "}
                <span className="rc-tab-badge">
                  {n8nRecs.length}
                </span>
              </div>

              {!n8nLoading &&
                !n8nError &&
                n8nRecs.map((it) => {
                  const deferredMatch = currentSegOverride?.mlrDefer?.rule === it.text;
                  const riskMatch = currentSegOverride?.acceptedRisk?.rule === it.text;
                  const hasDecision = deferredMatch || riskMatch;

                  return (
                    <div key={it.id} className="rcm-issue rcm-issue--reco">
                      <div className="rcm-issue__content">{it.text}</div>

                      {!hasDecision && (
                        <div className="rcm-issue__actions">
                         <button
  className="btn hollow-success"
  disabled={isLocked && decisionType !== "accept_reco"}
  onClick={() => acceptRecommendation(it.text)}
>
  ✓ Accept Recommendation
</button>
                         
<button
  className="btn outline-blue"
  disabled={isLocked}
  onClick={() => openDeferModal(it.text)}
>
  ☐ Defer to MLR Review
</button>

                         
<button
  className="btn ghost"
  disabled={isLocked}
  onClick={() => openRiskModal(it.text)}
>
  Accept Risk & Skip
</button>

                        </div>
                      )}

                      {deferredMatch && (
                        <div className="rcm-logged-note">
                          <div className="rcm-logged-note__label">Decision Reasoning:</div>
                          <textarea
                            className="rcm-logged-note__textarea"
                            value={currentSegOverride.mlrDefer.reasoning}
                            readOnly
                          />
                          <div className="rcm-logged-note__meta">
                            Logged at: {new Date(currentSegOverride.mlrDefer.at).toLocaleString()}
                          </div>
                        </div>
                      )}

                      {riskMatch && (
                        <div className="rcm-logged-note">
                          <div className="rcm-logged-note__label">Decision Reasoning:</div>
                          <textarea
                            className="rcm-logged-note__textarea"
                            value={currentSegOverride.acceptedRisk.reasoning}
                            readOnly
                          />
                          <div className="rcm-logged-note__meta">
                            Logged at: {new Date(currentSegOverride.acceptedRisk.at).toLocaleString()}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
            </div>

            {/* FOOTER */}
            <div className="rcm-modal__footer">
              <button
                className={`btn outline ${isReAnalyzing ? "is-loading" : ""}`}
                onClick={openAnalysisModal}//27_03_sanju
                disabled={isReAnalyzing || isReAnalyzeDisabled}
              >
                {isReAnalyzing ? "Re-analyzing…" : "Re-Analyze with AI"}
              </button>
              <div className="rcm-footer-right">
                <button className="btn success" onClick={markCompliantFromModal}>
                  ✓ Mark as Compliant
                </button>
                <button
                  className="btn ghost"
                  onClick={() => setIsAnalysisModalOpen(false)}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================== Request MLR Exception POPUP ================== */}
      {isMlrOpen && (
        <div
          className="mlr-modal-backdrop"
          role="dialog"
          aria-modal="true"
          aria-label="Request MLR Exception"
          onClick={(e) => {
            if (e.target === e.currentTarget) setIsMlrOpen(false);
          }}
        >
          <div className="mlr-modal">
            {/* Header */}
            <div className="mlr-header">
              <div className="mlr-title">
                <span className="mlr-warn-icon">⚠</span> Request MLR Exception
              </div>
              <button
                className="mlr-close"
                aria-label="Close"
                onClick={() => setIsMlrOpen(false)}
              >
                ✕
              </button>
            </div>

            {/* Subtext */}
            <div className="mlr-subtext">
              Explain why this critical compliance issue requires an exception. This will
              be escalated to the Medical Legal Regulatory team for approval.
            </div>

            {/* Rule */}
            <div className="mlr-label">Rule</div>
            <div className="mlr-rule-box">{mlrRuleText || "No rule text available."}</div>

            {/* Reasoning */}
            <div className="mlr-label req">Reasoning *</div>
            <textarea
              className={`mlr-textarea ${mlrTouched && !mlrReason.trim() ? "is-invalid" : ""}`}
              placeholder="Enter detailed reasoning for this decision..."
              value={mlrReason}
              onChange={(e) => setMlrReason(e.target.value)}
              onBlur={() => setMlrTouched(true)}
            />

            <div className="mlr-hint">This reasoning will be logged for audit purposes.</div>

            {/* Footer */}
            <div className="mlr-footer">
              <button className="btn ghost" onClick={() => setIsMlrOpen(false)}>
                Cancel
              </button>
              <button
                className="btn primary"
                onClick={submitMlr}
                disabled={!mlrReason.trim() || mlrSubmitting}
              >
                {mlrSubmitting ? "Submitting…" : "Submit"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================== Defer to MLR Review POPUP ================== */}
      {isDeferOpen && (
        <div
          className="mlr-modal-backdrop"
          role="dialog"
          aria-modal="true"
          aria-label="Defer to MLR Review"
          onClick={(e) => {
            if (e.target === e.currentTarget) setIsDeferOpen(false);
          }}
        >
          <div className="mlr-modal">
            {/* Header */}
            <div className="mlr-header">
              <div className="mlr-title">
                <span className="mlr-warn-icon">⚠</span> Defer to MLR Review
              </div>
              <button
                className="mlr-close"
                aria-label="Close"
                onClick={() => setIsDeferOpen(false)}
              >
                ✕
              </button>
            </div>

            {/* Subtext */}
            <div className="mlr-subtext">
              Provide context for the MLR team to review during the approval process.
              Explain why manual review is needed.
            </div>

            {/* Rule */}
            <div className="mlr-label">Rule</div>
            <div className="mlr-rule-box">{deferRuleText || "No rule text available."}</div>

            {/* Reasoning */}
            <div className="mlr-label req">Reasoning *</div>
            <textarea
              className={`mlr-textarea ${
                deferTouched && !deferReason.trim() ? "is-invalid" : ""
              }`}
              placeholder="Enter detailed reasoning for this decision..."
              value={deferReason}
              onChange={(e) => setDeferReason(e.target.value)}
              onBlur={() => setDeferTouched(true)}
            />

            <div className="mlr-hint">This reasoning will be logged for audit purposes.</div>

            {/* Footer */}
            <div className="mlr-footer">
              <button className="btn ghost" onClick={() => setIsDeferOpen(false)}>
                Cancel
              </button>
              <button
                className="btn primary"
                onClick={submitDefer}
                disabled={!deferReason.trim() || deferSubmitting}
              >
                {deferSubmitting ? "Submitting…" : "Submit"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================== Accept Risk & Skip POPUP ================== */}
      {isRiskOpen && (
        <div
          className="mlr-modal-backdrop"
          role="dialog"
          aria-modal="true"
          aria-label="Accept Risk &amp; Skip"
          onClick={(e) => {
            if (e.target === e.currentTarget) setIsRiskOpen(false);
          }}
        >
          <div className="mlr-modal">
            {/* Header */}
            <div className="mlr-header">
              <div className="mlr-title">
                <span className="mlr-warn-icon">⚠</span> Accept Risk &amp; Skip
              </div>
              <button
                className="mlr-close"
                aria-label="Close"
                onClick={() => setIsRiskOpen(false)}
              >
                ✕
              </button>
            </div>

            {/* Subtext */}
            <div className="mlr-subtext">
              Document your decision to skip this recommendation. Include your rationale
              and any risk assessment considerations.
            </div>

            {/* Rule */}
            <div className="mlr-label">Rule</div>
            <div className="mlr-rule-box">{riskRuleText || "No rule text available."}</div>

            {/* Reasoning */}
            <div className="mlr-label req">Reasoning *</div>
            <textarea
              className={`mlr-textarea ${
                riskTouched && !riskReason.trim() ? "is-invalid" : ""
              }`}
              placeholder="Enter detailed reasoning for this decision..."
              value={riskReason}
              onChange={(e) => setRiskReason(e.target.value)}
              onBlur={() => setRiskTouched(true)}
            />

            <div className="mlr-hint">This reasoning will be logged for audit purposes.</div>

            {/* Footer */}
            <div className="mlr-footer">
              <button className="btn ghost" onClick={() => setIsRiskOpen(false)}>
                Cancel
              </button>
              <button
                className="btn primary"
                onClick={submitRisk}
                disabled={!riskReason.trim() || riskSubmitting}
              >
                {riskSubmitting ? "Submitting…" : "Submit"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================== Mark as Blocking POPUP ================== */}
      {isBlockOpen && (
        <div
          className="mlr-modal-backdrop"
          role="dialog"
          aria-modal="true"
          aria-labelledby="blockTitle"
          onClick={(e) => {
            if (e.target === e.currentTarget) setIsBlockOpen(false);
          }}
        >
          <div className="block-modal">
            <div className="block-header">
              <div className="block-title" id="blockTitle">
                <span className="block-warn-circ">i</span>
                Blocking Decision
              </div>
              <span className="block-badge">Blocking</span>
              <button
                className="block-close"
                aria-label="Close"
                onClick={() => setIsBlockOpen(false)}
              >
                ✕
              </button>
            </div>

            <div className="block-card">
              <div className="block-icon">!</div>
              <div className="block-text">{blockRuleText || "No rule text available."}</div>
            </div>

            <div className="block-reason-wrap">
              <div className="block-reason-label">Decision Reasoning:</div>
              <textarea
                className={`block-reason ${blockTouched && !blockReason.trim() ? "is-invalid" : ""}`}
                value={blockReason}
                onChange={(e) => setBlockReason(e.target.value)}
                onBlur={() => setBlockTouched(true)}
                placeholder="Add any additional context for why this is blocking..."
              />
            </div>

            <div className="block-footer">
              <button className="btn ghost" onClick={() => setIsBlockOpen(false)}>
                Cancel
              </button>
              <button
                className="btn danger"
                onClick={submitBlock}
                disabled={!blockReason.trim() || blockSubmitting}
                title={!blockReason.trim() ? "Reasoning is required" : "Submit blocking decision"}
              >
                {blockSubmitting ? "Marking…" : "Mark as Blocking"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ================== Small Component: Regulatory Intelligence Inner Tabs ================== */
function IntelInnerTabs({ locale = "DE", overallPct = 100 }) {
  const [tab, setTab] = useState("matrix"); // matrix | pre | templates | realtime

  return (
    <div className="intel-tabs">
      <div className="intel-tabbar">
        <button className={tab === "matrix" ? "active" : ""} onClick={() => setTab("matrix")}>
          Compliance Matrix
        </button>
        <button className={tab === "pre" ? "active" : ""} onClick={() => setTab("pre")}>
          Pre-Approved Content
        </button>
        <button className={tab === "templates" ? "active" : ""} onClick={() => setTab("templates")}>
          Templates
        </button>
        <button className={tab === "realtime" ? "active" : ""} onClick={() => setTab("realtime")}>
          Real-Time Validator
        </button>
      </div>

      {tab === "matrix" && (
        <div className="intel-panel">
          <div className="intel-matrix-row">
            <div className="intel-matrix-label">{locale}</div>
            <div className="intel-matrix-bar" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={overallPct}>
              <div className="intel-matrix-fill" style={{ width: `${overallPct}%` }} />
              <span className="intel-matrix-pct">{overallPct}%</span>
            </div>
          </div>
        </div>
      )}

      {tab === "pre" && (
        <div className="intel-panel">
          <div className="intel-placeholder">
            No pre-approved content linked. Use your brand library to attach items.
          </div>
        </div>
      )}

      {tab === "templates" && (
        <div className="intel-panel">
          <div className="intel-templates">
            <div className="intel-template-card">
              <div className="intel-template-title">HWG Disclosure Boilerplate</div>
              <div className="intel-template-sub">Localized: {locale}</div>
              <button className="rc-btn tiny">Insert</button>
            </div>
            <div className="intel-template-card">
              <div className="intel-template-title">Social Media Risk Footnote</div>
              <div className="intel-template-sub">Localized: {locale}</div>
              <button className="rc-btn tiny">Insert</button>
            </div>
          </div>
        </div>
      )}

      {tab === "realtime" && (
        <div className="intel-panel">
          <div className="intel-validator">
            <div className="intel-validator-head">
              Real-Time Validator
              <span className="rc-chip small">Beta</span>
            </div>
            <div className="intel-validator-bar" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={overallPct}>
              <div className="intel-validator-fill" style={{ width: `${overallPct}%` }} />
              <span className="intel-validator-pct">{overallPct}%</span>
            </div>
            <div className="intel-placeholder small">Live checks are green. No critical issues.</div>
          </div>
        </div>
      )}
    </div>
  );
}

// /* Sidebar phases */
// const SIDEBAR_PHASES = [
//   { id: 'P1', name: "Global Context Capture", sub: "Source content analysis", status: "done", iconClass: "icon-context" },
//   { id: 'P2', name: "Smart TM Translation", sub: "AI-powered translation", status: "done", iconClass: "icon-translation" },
//   { id: 'P3', name: "Cultural Intelligence", sub: "Cultural adaptation", status: "done", iconClass: "icon-culture" },
//   { id: 'P4', name: "Regulatory Compliance", sub: "Compliance validation", status: "active", iconClass: "icon-compliance" },
//   { id: 'P5', name: "Quality Intelligence", sub: "Quality assurance", status: "todo", iconClass: "icon-quality" },
//   { id: 'P6', name: "DAM Integration", sub: "Asset packaging", status: "todo", iconClass: "icon-dam" },
//   { id: 'P7', name: "Integration Lineage", sub: "System integration", status: "todo", iconClass: "icon-integration" },
// ];

const SIDEBAR_PHASES = [
  {
    id: 'P1',
    name: "Global Context Capture",
    sub: "Source content analysis",
    status: "done",
    icon: <Globe size={18} />,
    color: 'is-blue'
  },
  {
    id: 'P2',
    name: "Smart TM Translation",
    sub: "AI-powered translation",
    status: "done",
    icon: <Languages size={18} />,
    color: 'is-purple'
  },
  {
    id: 'P3',
    name: "Cultural Intelligence",
    sub: "Cultural adaptation",
    status: "done",
    icon: <MessageSquare size={18} />,
    color: 'is-green'
  },
  {
    id: 'P4',
    name: "Regulatory Compliance",
    sub: "Compliance validation",
    status: "active",
    icon: <Shield size={18} />,
    color: 'is-orange'
  },
  {
    id: 'P5',
    name: "Quality Intelligence",
    sub: "Quality assurance",
    status: "todo",
    icon: <CheckCircleIcon size={18} />,
    color: 'is-cyan'
  },
  {
    id: 'P6',
    name: "DAM Integration",
    sub: "Asset packaging",
    status: "todo",
    icon: <Box size={18} />,
    color: 'is-pink'
  },
  {
    id: 'P7',
    name: "Integration Lineage",
    sub: "System integration",
    status: "todo",
    icon: <MessageSquare size={18} />,
    color: 'is-violet'
  },
];